import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Shield, ArrowLeft, Upload, FileText, X, CheckCircle } from 'lucide-react';
import { getToken, getCurrentUser } from '../lib/auth';

const scamTypes = [
  { value: 'phishing', label: 'Phishing Scam' },
  { value: 'investment_fraud', label: 'Investment Fraud' },
  { value: 'romance_scam', label: 'Romance Scam' },
  { value: 'crypto_scam', label: 'Cryptocurrency Scam' },
  { value: 'tech_support', label: 'Tech Support Scam' },
  { value: 'identity_theft', label: 'Identity Theft' },
  { value: 'wire_fraud', label: 'Wire Fraud' },
  { value: 'credit_card', label: 'Credit Card Fraud' },
  { value: 'other', label: 'Other' },
];

export default function SubmitCasePage() {
  const [checkingAuth, setCheckingAuth] = useState(true);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [caseId, setCaseId] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [amountLost, setAmountLost] = useState('');
  const [scamType, setScamType] = useState('');
  const [description, setDescription] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const navigate = useNavigate();
  const token = getToken();

  useEffect(() => {
    getCurrentUser().then(u => {
      if (!u) navigate('/auth/sign-up?redirect=/submit-case');
      setCheckingAuth(false);
    });
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/cases', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ title, scam_type: scamType, amount_lost: parseFloat(amountLost), description }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to submit case');
      setCaseId(data.case_id);
      setSubmitted(true);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (checkingAuth) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: '#0a1628' }}>
      <div className="w-8 h-8 rounded-full border-2 border-t-transparent" style={{ borderColor: '#d4a853', animation: 'spin 1s linear infinite' }} />
    </div>
  );

  if (submitted) return (
    <div className="min-h-screen flex flex-col" style={{ background: '#0a1628' }}>
      <div className="p-4"><Link to="/" className="inline-flex items-center gap-2 text-sm" style={{ color: '#94a3b8' }}><ArrowLeft className="w-4 h-4" /> Back to Home</Link></div>
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md text-center">
          <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6" style={{ background: 'rgba(34,197,94,0.2)' }}>
            <CheckCircle className="w-10 h-10" style={{ color: '#22c55e' }} />
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">Case Submitted Successfully!</h1>
          <p className="mb-4" style={{ color: '#94a3b8' }}>Your case has been received and is under review.</p>
          <div className="rounded-lg p-4 mb-6" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
            <p className="text-sm mb-1" style={{ color: '#94a3b8' }}>Your Case ID</p>
            <p className="text-xl font-mono font-bold" style={{ color: '#d4a853' }}>{caseId}</p>
          </div>
          <button onClick={() => navigate('/dashboard')} className="w-full h-12 rounded-lg font-semibold" style={{ background: '#d4a853', color: '#0a1628' }}>Go to Dashboard</button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#0a1628' }}>
      <div className="p-4"><Link to="/" className="inline-flex items-center gap-2 text-sm" style={{ color: '#94a3b8' }}><ArrowLeft className="w-4 h-4" /> Back to Home</Link></div>
      <div className="flex-1 flex items-center justify-center p-4 py-8">
        <div className="w-full max-w-2xl">
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 mb-4">
              <Shield className="w-10 h-10" style={{ color: '#d4a853' }} />
              <span className="text-2xl font-bold text-white">CRA</span>
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">Submit Your Case</h1>
            <p style={{ color: '#94a3b8' }}>Fill out the form below to begin your fund recovery process</p>
          </div>
          <form onSubmit={handleSubmit} className="space-y-6 rounded-xl p-6" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: '#94a3b8' }}>Case Title</label>
              <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Brief title describing your case" required
                className="w-full h-12 px-3 rounded-lg text-white text-sm outline-none placeholder:opacity-50" style={{ background: '#0a1628', border: '1px solid #1e4976' }} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1" style={{ color: '#94a3b8' }}>Amount Lost ($)</label>
                <input type="number" value={amountLost} onChange={e => setAmountLost(e.target.value)} placeholder="Enter amount" required min="0" step="0.01"
                  className="w-full h-12 px-3 rounded-lg text-white text-sm outline-none placeholder:opacity-50" style={{ background: '#0a1628', border: '1px solid #1e4976' }} />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1" style={{ color: '#94a3b8' }}>Scam Type</label>
                <select value={scamType} onChange={e => setScamType(e.target.value)} required
                  className="w-full h-12 px-3 rounded-lg text-white text-sm outline-none" style={{ background: '#0a1628', border: '1px solid #1e4976' }}>
                  <option value="">Select scam type</option>
                  {scamTypes.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                </select>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: '#94a3b8' }}>Description of Incident</label>
              <textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="Please provide detailed information about the incident..." required rows={5}
                className="w-full px-3 py-2 rounded-lg text-white text-sm outline-none resize-none placeholder:opacity-50" style={{ background: '#0a1628', border: '1px solid #1e4976' }} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1" style={{ color: '#94a3b8' }}>Upload Evidence (Optional)</label>
              <div className="rounded-lg p-6 text-center" style={{ border: '2px dashed #1e4976' }}>
                <input type="file" id="evidence" multiple onChange={e => setFiles(Array.from(e.target.files || []))} className="hidden" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" />
                <label htmlFor="evidence" className="cursor-pointer">
                  <Upload className="w-8 h-8 mx-auto mb-2" style={{ color: '#94a3b8' }} />
                  <p style={{ color: '#94a3b8' }}>Click to upload files</p>
                  <p className="text-xs" style={{ color: '#64748b' }}>PDF, DOC, JPG, PNG</p>
                </label>
              </div>
              {files.length > 0 && <div className="space-y-2 mt-2">{files.map((f, i) => (
                <div key={i} className="flex items-center gap-2 p-2 rounded-lg" style={{ background: '#0a1628' }}>
                  <FileText className="w-4 h-4" style={{ color: '#d4a853' }} />
                  <span className="text-sm text-white flex-1 truncate">{f.name}</span>
                  <button type="button" onClick={() => setFiles(files.filter((_, j) => j !== i))} style={{ color: '#94a3b8' }}><X className="w-4 h-4" /></button>
                </div>
              ))}</div>}
            </div>
            {error && <div className="rounded-lg p-3 text-sm" style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.5)', color: '#f87171' }}>{error}</div>}
            <button type="submit" disabled={loading || !scamType} className="w-full h-12 rounded-lg font-semibold transition-colors" style={{ background: '#d4a853', color: '#0a1628', opacity: loading || !scamType ? 0.7 : 1 }}>
              {loading ? 'Submitting Case...' : 'Submit Case'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
