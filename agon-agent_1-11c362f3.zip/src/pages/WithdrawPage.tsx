import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Shield, ArrowLeft, Wallet, Building2, Bitcoin, CreditCard, Clock, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { getToken, getCurrentUser } from '../lib/auth';

type Withdrawal = { id: number; amount: number; method: string; status: string; admin_note?: string; created_at: string; };
type Case = { id: number; case_id: string; title: string; amount_recovered: number; };

const withdrawalMethods = [
  { value: 'bank_transfer', label: 'Bank Transfer', icon: Building2 },
  { value: 'crypto', label: 'Cryptocurrency Wallet', icon: Bitcoin },
  { value: 'bitso', label: 'Bitso', icon: CreditCard },
];

const statusConfig: Record<string, { color: string; bg: string; icon: any }> = {
  pending: { color: '#eab308', bg: 'rgba(234,179,8,0.2)', icon: Clock },
  processing: { color: '#3b82f6', bg: 'rgba(59,130,246,0.2)', icon: Loader2 },
  successful: { color: '#22c55e', bg: 'rgba(34,197,94,0.2)', icon: CheckCircle },
  failed: { color: '#ef4444', bg: 'rgba(239,68,68,0.2)', icon: XCircle },
};

export default function WithdrawPage() {
  const [cases, setCases] = useState<Case[]>([]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [dailyLimit, setDailyLimit] = useState(10000);
  const [availableBalance, setAvailableBalance] = useState(0);
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('');
  const [selectedCase, setSelectedCase] = useState('');
  const [walletAddress, setWalletAddress] = useState('');
  const [bankName, setBankName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [routingNumber, setRoutingNumber] = useState('');
  const [accountHolderName, setAccountHolderName] = useState('');
  const [bitsoEmail, setBitsoEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const navigate = useNavigate();
  const token = getToken();
  const authHeaders = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };

  useEffect(() => {
    const init = async () => {
      const u = await getCurrentUser();
      if (!u) { navigate('/auth/login'); return; }
      setDailyLimit(u.dailyWithdrawalLimit || 10000);
      const [casesRes, wdRes] = await Promise.all([
        fetch('/api/cases', { headers: authHeaders }),
        fetch('/api/withdrawals', { headers: authHeaders }),
      ]);
      const casesData = await casesRes.json();
      const wdData = await wdRes.json();
      const c = Array.isArray(casesData) ? casesData.filter((x: any) => x.amount_recovered > 0) : [];
      setCases(c);
      const totalRecovered = c.reduce((s: number, x: any) => s + Number(x.amount_recovered), 0);
      const wd = Array.isArray(wdData) ? wdData : [];
      setWithdrawals(wd);
      const totalWithdrawn = wd.filter((w: any) => ['pending','processing','successful'].includes(w.status)).reduce((s: number, w: any) => s + Number(w.amount), 0);
      setAvailableBalance(totalRecovered - totalWithdrawn);
      setLoading(false);
    };
    init();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    const amt = parseFloat(amount);
    if (amt > availableBalance) { setError('Withdrawal amount exceeds available balance'); setSubmitting(false); return; }
    if (amt > dailyLimit) { setError(`Withdrawal amount exceeds daily limit of $${dailyLimit.toLocaleString()}`); setSubmitting(false); return; }
    try {
      const res = await fetch('/api/withdrawals', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ amount: amt, method, wallet_address: method === 'crypto' ? walletAddress : null, bank_name: method === 'bank_transfer' ? bankName : null, account_number: method === 'bank_transfer' ? accountNumber : null, routing_number: method === 'bank_transfer' ? routingNumber : null, account_holder_name: method === 'bank_transfer' ? accountHolderName : null, bitso_email: method === 'bitso' ? bitsoEmail : null, case_id: selectedCase || null }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to submit withdrawal');
      setWithdrawals(prev => [data, ...prev]);
      setAvailableBalance(prev => prev - amt);
      setAmount(''); setMethod(''); setSelectedCase(''); setWalletAddress(''); setBankName(''); setAccountNumber(''); setRoutingNumber(''); setAccountHolderName(''); setBitsoEmail('');
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: '#0a1628' }}>
      <div className="w-8 h-8 rounded-full border-2 border-t-transparent" style={{ borderColor: '#d4a853', animation: 'spin 1s linear infinite' }} />
    </div>
  );

  const inputClass = "w-full h-12 px-3 rounded-lg text-white text-sm outline-none placeholder:opacity-50";
  const inputStyle = { background: '#0a1628', border: '1px solid #1e4976' };

  return (
    <div className="min-h-screen" style={{ background: '#0a1628' }}>
      <header className="sticky top-0 z-50" style={{ background: '#0f2140', borderBottom: '1px solid #1e4976' }}>
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/dashboard" className="flex items-center gap-2 text-sm transition-colors" style={{ color: '#94a3b8' }}>
            <ArrowLeft className="w-4 h-4" /> Back to Dashboard
          </Link>
          <Link to="/" className="flex items-center gap-2">
            <Shield className="w-8 h-8" style={{ color: '#d4a853' }} />
            <span className="text-xl font-bold text-white">CRA</span>
          </Link>
        </div>
      </header>
      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: 'rgba(212,168,83,0.2)' }}>
            <Wallet className="w-6 h-6" style={{ color: '#d4a853' }} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Withdraw Funds</h1>
            <p style={{ color: '#94a3b8' }}>Request a withdrawal from your recovered funds</p>
          </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="rounded-xl p-6" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
            <h2 className="text-lg font-semibold text-white mb-6">New Withdrawal Request</h2>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="rounded-lg p-4" style={{ background: '#0a1628' }}>
                <p className="text-xs mb-1" style={{ color: '#94a3b8' }}>Available Balance</p>
                <p className="text-xl font-bold" style={{ color: '#22c55e' }}>${availableBalance.toLocaleString()}</p>
              </div>
              <div className="rounded-lg p-4" style={{ background: '#0a1628' }}>
                <p className="text-xs mb-1" style={{ color: '#94a3b8' }}>Daily Limit</p>
                <p className="text-xl font-bold text-white">${dailyLimit.toLocaleString()}</p>
              </div>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1" style={{ color: '#94a3b8' }}>Amount ($)</label>
                <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="Enter amount" required min="1" step="0.01" max={Math.min(availableBalance, dailyLimit)} className={inputClass} style={inputStyle} />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1" style={{ color: '#94a3b8' }}>Withdrawal Method</label>
                <select value={method} onChange={e => setMethod(e.target.value)} required className="w-full h-12 px-3 rounded-lg text-white text-sm outline-none" style={inputStyle}>
                  <option value="">Select method</option>
                  {withdrawalMethods.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
                </select>
              </div>
              {cases.length > 0 && (
                <div>
                  <label className="block text-sm font-medium mb-1" style={{ color: '#94a3b8' }}>From Case (Optional)</label>
                  <select value={selectedCase} onChange={e => setSelectedCase(e.target.value)} className="w-full h-12 px-3 rounded-lg text-white text-sm outline-none" style={inputStyle}>
                    <option value="">Select case</option>
                    {cases.map(c => <option key={c.id} value={c.id}>{c.case_id} - ${Number(c.amount_recovered).toLocaleString()}</option>)}
                  </select>
                </div>
              )}
              {method === 'bank_transfer' && (
                <div className="space-y-3 p-4 rounded-lg" style={{ background: '#0a1628' }}>
                  <input value={accountHolderName} onChange={e => setAccountHolderName(e.target.value)} placeholder="Account Holder Name" required className={inputClass} style={{ background: '#0f2140', border: '1px solid #1e4976' }} />
                  <input value={bankName} onChange={e => setBankName(e.target.value)} placeholder="Bank Name" required className={inputClass} style={{ background: '#0f2140', border: '1px solid #1e4976' }} />
                  <input value={accountNumber} onChange={e => setAccountNumber(e.target.value)} placeholder="Account Number" required className={inputClass} style={{ background: '#0f2140', border: '1px solid #1e4976' }} />
                  <input value={routingNumber} onChange={e => setRoutingNumber(e.target.value)} placeholder="Routing Number" required className={inputClass} style={{ background: '#0f2140', border: '1px solid #1e4976' }} />
                </div>
              )}
              {method === 'crypto' && (
                <div>
                  <label className="block text-sm font-medium mb-1" style={{ color: '#94a3b8' }}>Wallet Address</label>
                  <input value={walletAddress} onChange={e => setWalletAddress(e.target.value)} placeholder="Enter your crypto wallet address" required className={inputClass + ' font-mono text-xs'} style={inputStyle} />
                </div>
              )}
              {method === 'bitso' && (
                <div>
                  <label className="block text-sm font-medium mb-1" style={{ color: '#94a3b8' }}>Bitso Email</label>
                  <input type="email" value={bitsoEmail} onChange={e => setBitsoEmail(e.target.value)} placeholder="Enter your Bitso account email" required className={inputClass} style={inputStyle} />
                </div>
              )}
              {error && <div className="rounded-lg p-3 text-sm" style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.5)', color: '#f87171' }}>{error}</div>}
              {success && <div className="rounded-lg p-3 text-sm" style={{ background: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.5)', color: '#22c55e' }}>Withdrawal request submitted successfully!</div>}
              <button type="submit" disabled={submitting || !method || availableBalance <= 0} className="w-full h-12 rounded-lg font-semibold transition-colors" style={{ background: '#d4a853', color: '#0a1628', opacity: submitting || !method || availableBalance <= 0 ? 0.7 : 1 }}>
                {submitting ? 'Processing...' : 'Submit Withdrawal Request'}
              </button>
            </form>
          </div>
          <div className="rounded-xl p-6" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
            <h2 className="text-lg font-semibold text-white mb-6">Withdrawal History</h2>
            {withdrawals.length === 0 ? (
              <div className="text-center py-12">
                <Wallet className="w-12 h-12 mx-auto mb-4" style={{ color: '#94a3b8' }} />
                <p style={{ color: '#94a3b8' }}>No withdrawal requests yet</p>
              </div>
            ) : (
              <div className="space-y-4 max-h-[500px] overflow-y-auto">
                {withdrawals.map(w => {
                  const s = statusConfig[w.status] || statusConfig.pending;
                  const StatusIcon = s.icon;
                  const mInfo = withdrawalMethods.find(m => m.value === w.method);
                  const MIcon = mInfo?.icon || CreditCard;
                  return (
                    <div key={w.id} className="rounded-lg p-4" style={{ background: '#0a1628', border: '1px solid #1e4976' }}>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <MIcon className="w-4 h-4" style={{ color: '#94a3b8' }} />
                          <span className="text-sm" style={{ color: '#94a3b8' }}>{mInfo?.label || w.method}</span>
                        </div>
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs" style={{ background: s.bg, color: s.color }}>
                          <StatusIcon className="w-3 h-3" />{w.status.charAt(0).toUpperCase() + w.status.slice(1)}
                        </span>
                      </div>
                      <p className="text-xl font-bold text-white mb-1">${Number(w.amount).toLocaleString()}</p>
                      <p className="text-xs" style={{ color: '#64748b' }}>{new Date(w.created_at).toLocaleString()}</p>
                      {w.admin_note && <p className="mt-2 text-sm p-2 rounded" style={{ color: '#94a3b8', background: '#0f2140' }}>Note: {w.admin_note}</p>}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
