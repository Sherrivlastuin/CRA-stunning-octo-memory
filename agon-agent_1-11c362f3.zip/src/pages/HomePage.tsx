import Header from '../components/Header';
import Hero from '../components/Hero';
import About from '../components/About';
import Services from '../components/Services';
import Process from '../components/Process';
import FAQ from '../components/FAQ';
import Contact from '../components/Contact';
import Footer from '../components/Footer';

export default function HomePage() {
  return (
    <main className="min-h-screen" style={{ background: '#0a1628' }}>
      <Header />
      <Hero />
      <About />
      <Services />
      <Process />
      <FAQ />
      <Contact />
      <Footer />
    </main>
  );
}
