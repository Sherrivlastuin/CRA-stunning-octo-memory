import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Shield, Mail, Lock, ArrowLeft } from 'lucide-react';
import { setToken } from '../lib/auth';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Login failed'); return; }
      setToken(data.token);
      navigate(data.user.isAdmin ? '/admin' : '/dashboard');
    } catch (err) {
      setError('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#0a1628' }}>
      <div className="p-4">
        <Link to="/" className="inline-flex items-center gap-2 text-sm transition-colors" style={{ color: '#94a3b8' }}>
          <ArrowLeft className="w-4 h-4" /> Back to Home
        </Link>
      </div>
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 mb-4">
              <Shield className="w-10 h-10" style={{ color: '#d4a853' }} />
              <span className="text-2xl font-bold text-white">CRA</span>
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">Welcome Back</h1>
            <p style={{ color: '#94a3b8' }}>Sign in to access your dashboard</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium" style={{ color: '#94a3b8' }}>Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5" style={{ color: '#94a3b8' }} />
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Enter your email" required
                  className="w-full h-12 pl-10 pr-3 rounded-lg text-white text-sm outline-none placeholder:opacity-50" style={{ background: '#0f2140', border: '1px solid #1e4976' }} />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium" style={{ color: '#94a3b8' }}>Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5" style={{ color: '#94a3b8' }} />
                <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Enter your password" required
                  className="w-full h-12 pl-10 pr-3 rounded-lg text-white text-sm outline-none placeholder:opacity-50" style={{ background: '#0f2140', border: '1px solid #1e4976' }} />
              </div>
            </div>
            {error && <div className="rounded-lg p-3 text-sm" style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.5)', color: '#f87171' }}>{error}</div>}
            <button type="submit" disabled={loading} className="w-full h-12 rounded-lg font-semibold transition-colors" style={{ background: '#d4a853', color: '#0a1628' }}>
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>
          <p className="text-center mt-6" style={{ color: '#94a3b8' }}>
            Don't have an account? <Link to="/auth/sign-up" style={{ color: '#d4a853' }}>Sign up</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
