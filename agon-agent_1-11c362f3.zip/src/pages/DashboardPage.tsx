import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Shield, LogOut, FileText, DollarSign, Clock, CheckCircle, AlertCircle, TrendingUp, Plus, Wallet, MessageSquare, User } from 'lucide-react';
import { getToken, removeToken, getCurrentUser } from '../lib/auth';

type Case = { id: number; case_id: string; title: string; scam_type: string; amount_lost: number; amount_recovered: number; status: string; created_at: string; };
type Message = { id: number; case_id: number; sender_type: string; message: string; is_read: boolean; created_at: string; };

const statusColors: Record<string, { bg: string; text: string; icon: any }> = {
  under_review: { bg: 'rgba(234,179,8,0.2)', text: '#eab308', icon: Clock },
  in_progress: { bg: 'rgba(59,130,246,0.2)', text: '#3b82f6', icon: TrendingUp },
  recovered: { bg: 'rgba(34,197,94,0.2)', text: '#22c55e', icon: CheckCircle },
  closed: { bg: 'rgba(107,114,128,0.2)', text: '#6b7280', icon: AlertCircle },
};
const statusLabels: Record<string, string> = { under_review: 'Under Review', in_progress: 'In Progress', recovered: 'Recovered', closed: 'Closed' };

export default function DashboardPage() {
  const [user, setUser] = useState<any>(null);
  const [cases, setCases] = useState<Case[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'cases' | 'messages'>('overview');
  const navigate = useNavigate();
  const token = getToken();

  const authHeaders = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };

  useEffect(() => {
    const init = async () => {
      const u = await getCurrentUser();
      if (!u) { navigate('/auth/login'); return; }
      if (u.isAdmin) { navigate('/admin'); return; }
      setUser(u);
      await fetchData();
      setLoading(false);
    };
    init();
  }, []);

  const fetchData = async () => {
    const [casesRes, msgsRes] = await Promise.all([
      fetch('/api/cases', { headers: authHeaders }),
      fetch('/api/messages', { headers: authHeaders }),
    ]);
    const casesData = await casesRes.json();
    const msgsData = await msgsRes.json();
    if (Array.isArray(casesData)) setCases(casesData);
    if (Array.isArray(msgsData)) setMessages(msgsData);
  };

  const handleSignOut = async () => {
    await fetch('/api/auth/signout', { method: 'POST', headers: authHeaders });
    removeToken();
    navigate('/');
  };

  const totalLost = cases.reduce((s, c) => s + Number(c.amount_lost), 0);
  const totalRecovered = cases.reduce((s, c) => s + Number(c.amount_recovered), 0);
  const unreadMessages = messages.filter(m => !m.is_read && m.sender_type === 'admin').length;

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: '#0a1628' }}>
      <div className="w-8 h-8 rounded-full border-2 border-t-transparent" style={{ borderColor: '#d4a853', animation: 'spin 1s linear infinite' }} />
    </div>
  );

  const CaseCard = ({ c }: { c: Case }) => {
    const s = statusColors[c.status] || statusColors.under_review;
    const StatusIcon = s.icon;
    return (
      <div className="rounded-lg p-4" style={{ background: '#0a1628', border: '1px solid #1e4976' }}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono" style={{ color: '#d4a853' }}>{c.case_id}</span>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs" style={{ background: s.bg, color: s.text }}>
                <StatusIcon className="w-3 h-3" />{statusLabels[c.status]}
              </span>
            </div>
            <h3 className="text-white font-medium">{c.title}</h3>
            <p className="text-sm" style={{ color: '#94a3b8' }}>{new Date(c.created_at).toLocaleDateString()}</p>
          </div>
          <div className="flex items-center gap-6">
            <div className="text-right">
              <p className="text-xs" style={{ color: '#94a3b8' }}>Amount Lost</p>
              <p className="text-white font-semibold">${Number(c.amount_lost).toLocaleString()}</p>
            </div>
            <div className="text-right">
              <p className="text-xs" style={{ color: '#94a3b8' }}>Recovered</p>
              <p className="font-semibold" style={{ color: '#22c55e' }}>${Number(c.amount_recovered).toLocaleString()}</p>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen" style={{ background: '#0a1628' }}>
      <header className="sticky top-0 z-50" style={{ background: '#0f2140', borderBottom: '1px solid #1e4976' }}>
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Shield className="w-8 h-8" style={{ color: '#d4a853' }} />
            <span className="text-xl font-bold text-white">CRA</span>
          </Link>
          <div className="flex items-center gap-4">
            <span className="text-sm hidden md:block" style={{ color: '#94a3b8' }}>Welcome, {user?.firstName || user?.email}</span>
            <button onClick={handleSignOut} className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors" style={{ color: '#94a3b8' }}>
              <LogOut className="w-4 h-4" /> Sign Out
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          {[{ id: 'overview', label: 'Overview', icon: User }, { id: 'cases', label: 'My Cases', icon: FileText }, { id: 'messages', label: 'Messages', icon: MessageSquare }].map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id as any)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors"
              style={activeTab === tab.id ? { background: '#d4a853', color: '#0a1628' } : { color: '#94a3b8' }}>
              <tab.icon className="w-4 h-4" />{tab.label}
              {tab.id === 'messages' && unreadMessages > 0 && <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">{unreadMessages}</span>}
            </button>
          ))}
          <Link to="/dashboard/withdraw" className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors" style={{ color: '#94a3b8' }}>
            <Wallet className="w-4 h-4" /> Withdraw
          </Link>
        </div>

        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {[{ icon: FileText, label: 'Total Cases', value: cases.length, color: '#d4a853', bg: 'rgba(212,168,83,0.2)' },
                { icon: DollarSign, label: 'Amount Lost', value: `$${totalLost.toLocaleString()}`, color: '#ef4444', bg: 'rgba(239,68,68,0.2)' },
                { icon: TrendingUp, label: 'Amount Recovered', value: `$${totalRecovered.toLocaleString()}`, color: '#22c55e', bg: 'rgba(34,197,94,0.2)' },
                { icon: Wallet, label: 'Available to Withdraw', value: `$${totalRecovered.toLocaleString()}`, color: '#3b82f6', bg: 'rgba(59,130,246,0.2)' },
              ].map(({ icon: Icon, label, value, color, bg }) => (
                <div key={label} className="rounded-xl p-6" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: bg }}>
                      <Icon className="w-5 h-5" style={{ color }} />
                    </div>
                    <span className="text-sm" style={{ color: '#94a3b8' }}>{label}</span>
                  </div>
                  <p className="text-3xl font-bold" style={{ color: label === 'Amount Recovered' ? '#22c55e' : 'white' }}>{value}</p>
                </div>
              ))}
            </div>
            <div className="rounded-xl p-6" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-white">Recent Cases</h2>
                <Link to="/submit-case" className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium" style={{ background: '#d4a853', color: '#0a1628' }}>
                  <Plus className="w-4 h-4" /> New Case
                </Link>
              </div>
              {cases.length === 0 ? (
                <div className="text-center py-12">
                  <FileText className="w-12 h-12 mx-auto mb-4" style={{ color: '#94a3b8' }} />
                  <p className="mb-4" style={{ color: '#94a3b8' }}>No cases submitted yet</p>
                  <Link to="/submit-case" className="px-6 py-2 rounded-lg font-medium" style={{ background: '#d4a853', color: '#0a1628' }}>Submit Your First Case</Link>
                </div>
              ) : cases.slice(0, 5).map(c => <div key={c.id} className="mb-4"><CaseCard c={c} /></div>)}
            </div>
          </div>
        )}

        {activeTab === 'cases' && (
          <div className="rounded-xl p-6" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-white">All Cases</h2>
              <Link to="/submit-case" className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium" style={{ background: '#d4a853', color: '#0a1628' }}>
                <Plus className="w-4 h-4" /> New Case
              </Link>
            </div>
            {cases.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-12 h-12 mx-auto mb-4" style={{ color: '#94a3b8' }} />
                <p className="mb-4" style={{ color: '#94a3b8' }}>No cases submitted yet</p>
                <Link to="/submit-case" className="px-6 py-2 rounded-lg font-medium" style={{ background: '#d4a853', color: '#0a1628' }}>Submit Your First Case</Link>
              </div>
            ) : <div className="space-y-4">{cases.map(c => <CaseCard key={c.id} c={c} />)}</div>}
          </div>
        )}

        {activeTab === 'messages' && (
          <div className="rounded-xl p-6" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
            <h2 className="text-xl font-semibold text-white mb-6">Messages from Support</h2>
            {messages.length === 0 ? (
              <div className="text-center py-12">
                <MessageSquare className="w-12 h-12 mx-auto mb-4" style={{ color: '#94a3b8' }} />
                <p style={{ color: '#94a3b8' }}>No messages yet</p>
              </div>
            ) : (
              <div className="space-y-4">
                {messages.map(msg => (
                  <div key={msg.id} className={`p-4 rounded-lg`} style={msg.sender_type === 'admin' ? { background: '#1a3a5c', borderLeft: '4px solid #d4a853' } : { background: '#0a1628', border: '1px solid #1e4976' }}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium" style={{ color: msg.sender_type === 'admin' ? '#d4a853' : '#94a3b8' }}>
                        {msg.sender_type === 'admin' ? 'Support Team' : 'You'}
                      </span>
                      <span className="text-xs" style={{ color: '#64748b' }}>{new Date(msg.created_at).toLocaleString()}</span>
                    </div>
                    <p className="text-white">{msg.message}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
