import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Shield, LogOut, Users, FileText, Wallet, MessageSquare,
  DollarSign, TrendingUp, Search, Edit2, Trash2, Send, X,
  Check, PlusCircle, MinusCircle, Activity,
  RefreshCw, Ban, UserCheck, Clock,
  CheckCircle, XCircle, Loader2, CreditCard, History,
  ArrowUpCircle, ArrowDownCircle, Lock, Unlock
} from 'lucide-react';
import { getToken, removeToken, getCurrentUser } from '../lib/auth';

type Profile = {
  id: number; user_id: number; email: string; first_name: string; last_name: string;
  phone: string; is_admin: boolean; is_active: boolean; daily_withdrawal_limit: number; created_at: string;
};
type Case = {
  id: number; user_id: number; case_id: string; title: string; scam_type: string;
  amount_lost: number; amount_recovered: number; status: string; created_at: string; profiles?: any;
};
type Withdrawal = {
  id: number; user_id: number; amount: number; method: string; status: string;
  admin_note?: string; created_at: string; profiles?: any;
};
type AuditLog = {
  id: number; admin_user_id: number; action: string; target_user_id: number;
  details: any; created_at: string;
};
type BalanceAdjustment = {
  id: number; user_id: number; type: string; amount: number;
  balance_before: number; balance_after: number; reason: string; created_at: string;
};

const WITHDRAWAL_STATUSES = ['pending', 'processing', 'successful', 'failed', 'retry'] as const;
type WithdrawalStatus = typeof WITHDRAWAL_STATUSES[number];

const statusStyle: Record<string, { bg: string; color: string; icon: any }> = {
  pending:    { bg: 'rgba(234,179,8,0.2)',  color: '#eab308', icon: Clock },
  processing: { bg: 'rgba(59,130,246,0.2)', color: '#3b82f6', icon: Loader2 },
  successful: { bg: 'rgba(34,197,94,0.2)',  color: '#22c55e', icon: CheckCircle },
  failed:     { bg: 'rgba(239,68,68,0.2)',  color: '#ef4444', icon: XCircle },
  retry:      { bg: 'rgba(168,85,247,0.2)', color: '#a855f7', icon: RefreshCw },
  under_review:{ bg: 'rgba(234,179,8,0.2)', color: '#eab308', icon: Clock },
  in_progress:{ bg: 'rgba(59,130,246,0.2)', color: '#3b82f6', icon: TrendingUp },
  recovered:  { bg: 'rgba(34,197,94,0.2)',  color: '#22c55e', icon: CheckCircle },
  closed:     { bg: 'rgba(107,114,128,0.2)',color: '#6b7280', icon: XCircle },
};

const actionLabels: Record<string, string> = {
  balance_credit: '💰 Balance Credit',
  balance_debit: '💸 Balance Debit',
  account_activated: '✅ Account Activated',
  account_deactivated: '🚫 Account Deactivated',
  withdrawal_processing: '⚙️ Withdrawal → Processing',
  withdrawal_successful: '✅ Withdrawal → Successful',
  withdrawal_failed: '❌ Withdrawal → Failed',
  withdrawal_retry: '🔄 Withdrawal → Retry',
  withdrawal_pending: '⏳ Withdrawal → Pending',
  withdrawal_limit_updated: '🔧 Limit Updated',
};

export default function AdminPage() {
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'cases' | 'withdrawals' | 'audit'>('overview');
  const [users, setUsers] = useState<Profile[]>([]);
  const [cases, setCases] = useState<Case[]>([]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [_balanceHistory, setBalanceHistory] = useState<BalanceAdjustment[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  // Modals
  const [editingUser, setEditingUser] = useState<Profile | null>(null);
  const [editingCase, setEditingCase] = useState<Case | null>(null);
  const [withdrawalModal, setWithdrawalModal] = useState<Withdrawal | null>(null);
  const [balanceModal, setBalanceModal] = useState<Profile | null>(null);
  const [limitModal, setLimitModal] = useState<Profile | null>(null);
  const [messageModal, setMessageModal] = useState<{ userId: number; caseId?: number } | null>(null);
  const [messageText, setMessageText] = useState('');

  // Balance form
  const [balanceType, setBalanceType] = useState<'credit' | 'debit'>('credit');
  const [balanceAmount, setBalanceAmount] = useState('');
  const [balanceReason, setBalanceReason] = useState('');
  const [balanceRef, setBalanceRef] = useState('');

  // Withdrawal action form
  const [wdAction, setWdAction] = useState<WithdrawalStatus>('processing');
  const [wdNote, setWdNote] = useState('');

  // Limit form
  const [newLimit, setNewLimit] = useState('');
  const [limitReason, setLimitReason] = useState('');

  // Status feedback
  const [actionMsg, setActionMsg] = useState<{ text: string; ok: boolean } | null>(null);

  const navigate = useNavigate();
  const token = getToken();
  const authHeaders = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };

  useEffect(() => {
    const init = async () => {
      const u = await getCurrentUser();
      if (!u) { navigate('/auth/admin-login'); return; }
      if (!u.isAdmin) { navigate('/dashboard'); return; }
      await fetchAll();
      setLoading(false);
    };
    init();
  }, []);

  const fetchAll = async () => {
    const [usersRes, casesRes, wdRes, auditRes, balRes] = await Promise.all([
      fetch('/api/profiles', { headers: authHeaders }),
      fetch('/api/cases', { headers: authHeaders }),
      fetch('/api/withdrawals', { headers: authHeaders }),
      fetch('/api/admin/audit-logs', { headers: authHeaders }),
      fetch('/api/admin/balance', { headers: authHeaders }),
    ]);
    const ud = await usersRes.json();   if (Array.isArray(ud)) setUsers(ud);
    const cd = await casesRes.json();   if (Array.isArray(cd)) setCases(cd);
    const wd = await wdRes.json();      if (Array.isArray(wd)) setWithdrawals(wd);
    const al = await auditRes.json();   if (Array.isArray(al)) setAuditLogs(al);
    const bl = await balRes.json();     if (Array.isArray(bl)) setBalanceHistory(bl);
  };

  const flash = (text: string, ok = true) => {
    setActionMsg({ text, ok });
    setTimeout(() => setActionMsg(null), 4000);
  };

  const handleSignOut = async () => {
    await fetch('/api/auth/signout', { method: 'POST', headers: authHeaders });
    removeToken();
    navigate('/');
  };

  // ── Balance Adjustment ──────────────────────────────────────────────────────
  const submitBalance = async () => {
    if (!balanceModal || !balanceAmount) return;
    const res = await fetch('/api/admin/balance', {
      method: 'POST', headers: authHeaders,
      body: JSON.stringify({ user_id: balanceModal.user_id, type: balanceType, amount: parseFloat(balanceAmount), reason: balanceReason, reference_id: balanceRef }),
    });
    const data = await res.json();
    if (!res.ok) { flash(data.error || 'Failed', false); return; }
    flash(`✅ Balance ${balanceType}ed $${parseFloat(balanceAmount).toLocaleString()} successfully`);
    setBalanceModal(null); setBalanceAmount(''); setBalanceReason(''); setBalanceRef('');
    await fetchAll();
  };

  // ── Withdrawal Action ───────────────────────────────────────────────────────
  const submitWithdrawalAction = async () => {
    if (!withdrawalModal) return;
    const res = await fetch('/api/admin/withdrawal-action', {
      method: 'POST', headers: authHeaders,
      body: JSON.stringify({ withdrawal_id: withdrawalModal.id, action: wdAction, admin_note: wdNote }),
    });
    const data = await res.json();
    if (!res.ok) { flash(data.error || 'Failed', false); return; }
    flash(`✅ Withdrawal marked as ${wdAction}`);
    setWithdrawalModal(null); setWdNote('');
    await fetchAll();
  };

  // ── Account Status Toggle ───────────────────────────────────────────────────
  const toggleAccountStatus = async (u: Profile, reason?: string) => {
    const newStatus = !(u.is_active !== false);
    const res = await fetch('/api/admin/user-status', {
      method: 'POST', headers: authHeaders,
      body: JSON.stringify({ user_id: u.user_id, is_active: newStatus, reason }),
    });
    const data = await res.json();
    if (!res.ok) { flash(data.error || 'Failed', false); return; }
    flash(`✅ Account ${newStatus ? 'activated' : 'deactivated'} successfully`);
    setUsers(users.map(x => x.user_id === u.user_id ? { ...x, is_active: newStatus } : x));
    await fetchAll();
  };

  // ── Set Withdrawal Limit ────────────────────────────────────────────────────
  const submitLimit = async () => {
    if (!limitModal || !newLimit) return;
    const res = await fetch('/api/admin/set-limit', {
      method: 'POST', headers: authHeaders,
      body: JSON.stringify({ user_id: limitModal.user_id, daily_withdrawal_limit: parseFloat(newLimit), reason: limitReason }),
    });
    const data = await res.json();
    if (!res.ok) { flash(data.error || 'Failed', false); return; }
    flash(`✅ Daily limit set to $${parseFloat(newLimit).toLocaleString()}`);
    setLimitModal(null); setNewLimit(''); setLimitReason('');
    await fetchAll();
  };

  // ── Edit User ───────────────────────────────────────────────────────────────
  const updateUser = async (userId: number, updates: Partial<Profile>) => {
    await fetch('/api/profiles', { method: 'PUT', headers: authHeaders, body: JSON.stringify({ user_id: userId, ...updates }) });
    setUsers(users.map(u => u.user_id === userId ? { ...u, ...updates } : u));
    setEditingUser(null);
    flash('✅ User updated');
  };

  const deleteUser = async (userId: number) => {
    if (!confirm('Delete this user permanently? This cannot be undone.')) return;
    await fetch('/api/profiles', { method: 'DELETE', headers: authHeaders, body: JSON.stringify({ user_id: userId }) });
    setUsers(users.filter(u => u.user_id !== userId));
    flash('✅ User deleted');
  };

  // ── Edit Case ───────────────────────────────────────────────────────────────
  const updateCase = async (caseId: number, updates: Partial<Case>) => {
    await fetch('/api/cases', { method: 'PUT', headers: authHeaders, body: JSON.stringify({ id: caseId, ...updates }) });
    setCases(cases.map(c => c.id === caseId ? { ...c, ...updates } : c));
    setEditingCase(null);
    flash('✅ Case updated');
  };

  // ── Send Message ────────────────────────────────────────────────────────────
  const sendMessage = async () => {
    if (!messageModal || !messageText.trim()) return;
    await fetch('/api/messages', { method: 'POST', headers: authHeaders, body: JSON.stringify({ user_id: messageModal.userId, case_id: messageModal.caseId || null, message: messageText }) });
    setMessageModal(null); setMessageText('');
    flash('✅ Message sent');
  };

  // ── Stats ───────────────────────────────────────────────────────────────────
  const nonAdminUsers = users.filter(u => !u.is_admin);
  const activeUsers = nonAdminUsers.filter(u => u.is_active !== false).length;
  const totalRecovered = cases.reduce((s, c) => s + Number(c.amount_recovered), 0);
  const pendingWd = withdrawals.filter(w => w.status === 'pending').length;

  const filteredUsers = nonAdminUsers.filter(u =>
    (u.email + u.first_name + u.last_name).toLowerCase().includes(searchTerm.toLowerCase()));
  const filteredCases = cases.filter(c =>
    (c.case_id + c.title + (c.profiles?.email || '')).toLowerCase().includes(searchTerm.toLowerCase()));
  const filteredWithdrawals = withdrawals.filter(w =>
    ((w.profiles?.email || '') + w.status + w.method).toLowerCase().includes(searchTerm.toLowerCase()));

  const S = { background: '#0a1628', border: '1px solid #1e4976' };
  const inputCls = 'w-full h-10 px-3 rounded-lg text-white text-sm outline-none';

  const StatusBadge = ({ status }: { status: string }) => {
    const s = statusStyle[status] || { bg: 'rgba(107,114,128,0.2)', color: '#6b7280', icon: Clock };
    const Icon = s.icon;
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium"
        style={{ background: s.bg, color: s.color }}>
        <Icon className="w-3 h-3" />{status.replace('_', ' ')}
      </span>
    );
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: '#0a1628' }}>
      <div className="w-8 h-8 rounded-full border-2 border-t-transparent" style={{ borderColor: '#d4a853', animation: 'spin 1s linear infinite' }} />
    </div>
  );

  return (
    <div className="min-h-screen" style={{ background: '#0a1628' }}>

      {/* Flash message */}
      {actionMsg && (
        <div className="fixed top-4 right-4 z-[9999] px-5 py-3 rounded-xl text-sm font-semibold shadow-2xl transition-all"
          style={{ background: actionMsg.ok ? 'rgba(34,197,94,0.15)' : 'rgba(239,68,68,0.15)', border: `1px solid ${actionMsg.ok ? '#22c55e' : '#ef4444'}`, color: actionMsg.ok ? '#22c55e' : '#f87171' }}>
          {actionMsg.text}
        </div>
      )}

      {/* Header */}
      <header className="sticky top-0 z-50" style={{ background: '#0f2140', borderBottom: '1px solid #1e4976' }}>
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="w-8 h-8" style={{ color: '#d4a853' }} />
            <div>
              <span className="text-xl font-bold text-white">CRA Admin</span>
              <p className="text-xs" style={{ color: '#94a3b8' }}>Secure Management Console</p>
            </div>
          </div>
          <button onClick={handleSignOut} className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors" style={{ color: '#94a3b8' }}>
            <LogOut className="w-4 h-4" /> Sign Out
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">

        {/* Tabs */}
        <div className="flex flex-wrap gap-2 mb-8">
          {[
            { id: 'overview',    label: 'Overview',    icon: TrendingUp },
            { id: 'users',       label: 'Users',       icon: Users },
            { id: 'cases',       label: 'Cases',       icon: FileText },
            { id: 'withdrawals', label: 'Withdrawals', icon: Wallet },
            { id: 'audit',       label: 'Audit Log',   icon: History },
          ].map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id as any)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors"
              style={activeTab === tab.id ? { background: '#d4a853', color: '#0a1628' } : { color: '#94a3b8' }}>
              <tab.icon className="w-4 h-4" />{tab.label}
              {tab.id === 'withdrawals' && pendingWd > 0 && (
                <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">{pendingWd}</span>
              )}
            </button>
          ))}
        </div>

        {/* Search */}
        {activeTab !== 'overview' && activeTab !== 'audit' && (
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5" style={{ color: '#94a3b8' }} />
            <input value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="Search..."
              className="w-full h-12 pl-10 pr-3 rounded-lg text-white text-sm outline-none" style={{ background: '#0f2140', border: '1px solid #1e4976' }} />
          </div>
        )}

        {/* ── OVERVIEW ─────────────────────────────────────────────────────── */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { icon: Users,      label: 'Total Users',     value: nonAdminUsers.length,          color: '#3b82f6', bg: 'rgba(59,130,246,0.2)' },
                { icon: UserCheck,  label: 'Active Accounts', value: activeUsers,                   color: '#22c55e', bg: 'rgba(34,197,94,0.2)' },
                { icon: DollarSign, label: 'Total Recovered', value: `$${totalRecovered.toLocaleString()}`, color: '#d4a853', bg: 'rgba(212,168,83,0.2)' },
                { icon: Wallet,     label: 'Pending Withdrawals', value: pendingWd,                 color: '#f97316', bg: 'rgba(249,115,22,0.2)' },
              ].map(({ icon: Icon, label, value, color, bg }) => (
                <div key={label} className="rounded-xl p-5" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: bg }}>
                      <Icon className="w-5 h-5" style={{ color }} />
                    </div>
                    <span className="text-sm" style={{ color: '#94a3b8' }}>{label}</span>
                  </div>
                  <p className="text-2xl font-bold text-white">{value}</p>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Cases */}
              <div className="rounded-xl p-6" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
                <h3 className="text-lg font-semibold text-white mb-4">Recent Cases</h3>
                <div className="space-y-3">
                  {cases.slice(0, 5).map(c => (
                    <div key={c.id} className="flex items-center justify-between p-3 rounded-lg" style={{ background: '#0a1628' }}>
                      <div>
                        <p className="text-white font-medium text-sm">{c.case_id}</p>
                        <p className="text-xs" style={{ color: '#94a3b8' }}>{c.profiles?.email}</p>
                      </div>
                      <StatusBadge status={c.status} />
                    </div>
                  ))}
                  {cases.length === 0 && <p className="text-center py-4 text-sm" style={{ color: '#94a3b8' }}>No cases yet</p>}
                </div>
              </div>

              {/* Pending Withdrawals */}
              <div className="rounded-xl p-6" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
                <h3 className="text-lg font-semibold text-white mb-4">Pending Withdrawals</h3>
                <div className="space-y-3">
                  {withdrawals.filter(w => w.status === 'pending').slice(0, 5).map(w => (
                    <div key={w.id} className="flex items-center justify-between p-3 rounded-lg" style={{ background: '#0a1628' }}>
                      <div>
                        <p className="text-white font-semibold">${Number(w.amount).toLocaleString()}</p>
                        <p className="text-xs" style={{ color: '#94a3b8' }}>{w.profiles?.email} · {w.method.replace('_', ' ')}</p>
                      </div>
                      <button onClick={() => { setWithdrawalModal(w); setWdAction('processing'); setWdNote(''); }}
                        className="px-3 py-1 rounded-lg text-xs font-semibold" style={{ background: '#d4a853', color: '#0a1628' }}>
                        Review
                      </button>
                    </div>
                  ))}
                  {withdrawals.filter(w => w.status === 'pending').length === 0 && (
                    <p className="text-center py-4 text-sm" style={{ color: '#94a3b8' }}>No pending withdrawals</p>
                  )}
                </div>
              </div>

              {/* Recent Audit */}
              <div className="rounded-xl p-6 lg:col-span-2" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
                <h3 className="text-lg font-semibold text-white mb-4">Recent Admin Activity</h3>
                <div className="space-y-2">
                  {auditLogs.slice(0, 6).map(log => (
                    <div key={log.id} className="flex items-center justify-between p-3 rounded-lg" style={{ background: '#0a1628' }}>
                      <div>
                        <p className="text-white text-sm">{actionLabels[log.action] || log.action}</p>
                        <p className="text-xs" style={{ color: '#94a3b8' }}>
                          {log.details?.amount ? `$${Number(log.details.amount).toLocaleString()} · ` : ''}
                          {log.details?.reason || ''}
                        </p>
                      </div>
                      <span className="text-xs" style={{ color: '#64748b' }}>{new Date(log.created_at).toLocaleString()}</span>
                    </div>
                  ))}
                  {auditLogs.length === 0 && <p className="text-center py-4 text-sm" style={{ color: '#94a3b8' }}>No activity yet</p>}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── USERS ────────────────────────────────────────────────────────── */}
        {activeTab === 'users' && (
          <div className="rounded-xl overflow-hidden" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead style={{ background: '#0a1628' }}>
                  <tr>
                    {['User', 'Email', 'Status', 'Daily Limit', 'Joined', 'Actions'].map(h => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider" style={{ color: '#94a3b8' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filteredUsers.map(u => (
                    <tr key={u.id} style={{ borderBottom: '1px solid #1e4976' }}>
                      <td className="px-4 py-3 text-white text-sm font-medium">{u.first_name} {u.last_name}</td>
                      <td className="px-4 py-3 text-sm" style={{ color: '#94a3b8' }}>{u.email}</td>
                      <td className="px-4 py-3">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium"
                          style={u.is_active !== false
                            ? { background: 'rgba(34,197,94,0.15)', color: '#22c55e' }
                            : { background: 'rgba(239,68,68,0.15)', color: '#f87171' }}>
                          {u.is_active !== false ? <><UserCheck className="w-3 h-3" />Active</> : <><Ban className="w-3 h-3" />Inactive</>}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm" style={{ color: '#94a3b8' }}>${Number(u.daily_withdrawal_limit).toLocaleString()}</td>
                      <td className="px-4 py-3 text-sm" style={{ color: '#94a3b8' }}>{new Date(u.created_at).toLocaleDateString()}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1">
                          {/* Credit/Debit Balance */}
                          <button title="Adjust Balance" onClick={() => { setBalanceModal(u); setBalanceType('credit'); setBalanceAmount(''); setBalanceReason(''); setBalanceRef(''); }}
                            className="p-1.5 rounded-lg transition-colors" style={{ color: '#d4a853' }}>
                            <CreditCard className="w-4 h-4" />
                          </button>
                          {/* Set Limit */}
                          <button title="Set Withdrawal Limit" onClick={() => { setLimitModal(u); setNewLimit(String(u.daily_withdrawal_limit)); setLimitReason(''); }}
                            className="p-1.5 rounded-lg" style={{ color: '#3b82f6' }}>
                            <Lock className="w-4 h-4" />
                          </button>
                          {/* Activate / Deactivate */}
                          <button title={u.is_active !== false ? 'Deactivate Account' : 'Activate Account'}
                            onClick={() => toggleAccountStatus(u)}
                            className="p-1.5 rounded-lg"
                            style={{ color: u.is_active !== false ? '#f87171' : '#22c55e' }}>
                            {u.is_active !== false ? <Ban className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                          </button>
                          {/* Message */}
                          <button title="Send Message" onClick={() => setMessageModal({ userId: u.user_id })}
                            className="p-1.5 rounded-lg" style={{ color: '#94a3b8' }}>
                            <MessageSquare className="w-4 h-4" />
                          </button>
                          {/* Edit */}
                          <button title="Edit User" onClick={() => setEditingUser(u)}
                            className="p-1.5 rounded-lg" style={{ color: '#94a3b8' }}>
                            <Edit2 className="w-4 h-4" />
                          </button>
                          {/* Delete */}
                          <button title="Delete User" onClick={() => deleteUser(u.user_id)}
                            className="p-1.5 rounded-lg" style={{ color: '#f87171' }}>
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {filteredUsers.length === 0 && <p className="text-center py-8 text-sm" style={{ color: '#94a3b8' }}>No users found</p>}
            </div>
          </div>
        )}

        {/* ── CASES ────────────────────────────────────────────────────────── */}
        {activeTab === 'cases' && (
          <div className="rounded-xl overflow-hidden" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead style={{ background: '#0a1628' }}>
                  <tr>
                    {['Case ID', 'User', 'Type', 'Amount Lost', 'Recovered', 'Status', 'Actions'].map(h => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider" style={{ color: '#94a3b8' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filteredCases.map(c => (
                    <tr key={c.id} style={{ borderBottom: '1px solid #1e4976' }}>
                      <td className="px-4 py-3 font-mono text-sm font-semibold" style={{ color: '#d4a853' }}>{c.case_id}</td>
                      <td className="px-4 py-3 text-sm text-white">{c.profiles?.email || c.profiles?.first_name}</td>
                      <td className="px-4 py-3 text-sm capitalize" style={{ color: '#94a3b8' }}>{c.scam_type.replace('_', ' ')}</td>
                      <td className="px-4 py-3 text-sm text-white">${Number(c.amount_lost).toLocaleString()}</td>
                      <td className="px-4 py-3 text-sm font-semibold" style={{ color: '#22c55e' }}>${Number(c.amount_recovered).toLocaleString()}</td>
                      <td className="px-4 py-3"><StatusBadge status={c.status} /></td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1">
                          <button onClick={() => setMessageModal({ userId: c.user_id, caseId: c.id })} className="p-1.5 rounded-lg" style={{ color: '#94a3b8' }}><MessageSquare className="w-4 h-4" /></button>
                          <button onClick={() => setEditingCase(c)} className="p-1.5 rounded-lg" style={{ color: '#94a3b8' }}><Edit2 className="w-4 h-4" /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {filteredCases.length === 0 && <p className="text-center py-8 text-sm" style={{ color: '#94a3b8' }}>No cases found</p>}
            </div>
          </div>
        )}

        {/* ── WITHDRAWALS ──────────────────────────────────────────────────── */}
        {activeTab === 'withdrawals' && (
          <div className="rounded-xl overflow-hidden" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead style={{ background: '#0a1628' }}>
                  <tr>
                    {['User', 'Amount', 'Method', 'Status', 'Admin Note', 'Date', 'Actions'].map(h => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider" style={{ color: '#94a3b8' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filteredWithdrawals.map(w => (
                    <tr key={w.id} style={{ borderBottom: '1px solid #1e4976' }}>
                      <td className="px-4 py-3 text-sm text-white">{w.profiles?.email}</td>
                      <td className="px-4 py-3 text-sm font-bold text-white">${Number(w.amount).toLocaleString()}</td>
                      <td className="px-4 py-3 text-sm capitalize" style={{ color: '#94a3b8' }}>{w.method.replace('_', ' ')}</td>
                      <td className="px-4 py-3"><StatusBadge status={w.status} /></td>
                      <td className="px-4 py-3 text-xs max-w-[160px] truncate" style={{ color: '#94a3b8' }}>{w.admin_note || '—'}</td>
                      <td className="px-4 py-3 text-xs" style={{ color: '#94a3b8' }}>{new Date(w.created_at).toLocaleDateString()}</td>
                      <td className="px-4 py-3">
                        <button onClick={() => { setWithdrawalModal(w); setWdAction('processing'); setWdNote(w.admin_note || ''); }}
                          className="px-3 py-1 rounded-lg text-xs font-semibold" style={{ background: '#d4a853', color: '#0a1628' }}>
                          Manage
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {filteredWithdrawals.length === 0 && <p className="text-center py-8 text-sm" style={{ color: '#94a3b8' }}>No withdrawals found</p>}
            </div>
          </div>
        )}

        {/* ── AUDIT LOG ────────────────────────────────────────────────────── */}
        {activeTab === 'audit' && (
          <div className="space-y-4">
            <div className="rounded-xl p-4 flex items-center gap-3" style={{ background: 'rgba(212,168,83,0.08)', border: '1px solid rgba(212,168,83,0.3)' }}>
              <Activity className="w-5 h-5 flex-shrink-0" style={{ color: '#d4a853' }} />
              <p className="text-sm" style={{ color: '#94a3b8' }}>
                Complete tamper-evident log of all administrative actions. Every balance adjustment, status change, and account modification is recorded here.
              </p>
            </div>
            <div className="rounded-xl overflow-hidden" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead style={{ background: '#0a1628' }}>
                    <tr>
                      {['Action', 'Target User', 'Details', 'Timestamp'].map(h => (
                        <th key={h} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider" style={{ color: '#94a3b8' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {auditLogs.map(log => (
                      <tr key={log.id} style={{ borderBottom: '1px solid #1e4976' }}>
                        <td className="px-4 py-3 text-sm text-white">{actionLabels[log.action] || log.action}</td>
                        <td className="px-4 py-3 text-sm" style={{ color: '#94a3b8' }}>
                          {users.find(u => u.user_id === log.target_user_id)?.email || `User #${log.target_user_id}`}
                        </td>
                        <td className="px-4 py-3 text-xs max-w-xs" style={{ color: '#64748b' }}>
                          {log.details?.amount ? `$${Number(log.details.amount).toLocaleString()} ` : ''}
                          {log.details?.reason ? `· ${log.details.reason}` : ''}
                          {log.details?.new_status ? `→ ${log.details.new_status}` : ''}
                          {log.details?.new_limit ? `Limit: $${Number(log.details.new_limit).toLocaleString()}` : ''}
                        </td>
                        <td className="px-4 py-3 text-xs" style={{ color: '#64748b' }}>{new Date(log.created_at).toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {auditLogs.length === 0 && <p className="text-center py-8 text-sm" style={{ color: '#94a3b8' }}>No audit logs yet</p>}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* ── MODAL: Balance Adjustment ─────────────────────────────────────── */}
      {balanceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.75)' }}>
          <div className="w-full max-w-md rounded-2xl p-6" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-lg font-bold text-white">Adjust Balance</h3>
                <p className="text-xs mt-0.5" style={{ color: '#94a3b8' }}>{balanceModal.email}</p>
              </div>
              <button onClick={() => setBalanceModal(null)} style={{ color: '#94a3b8' }}><X className="w-5 h-5" /></button>
            </div>

            {/* Credit / Debit toggle */}
            <div className="grid grid-cols-2 gap-2 mb-5 p-1 rounded-xl" style={{ background: '#0a1628' }}>
              {(['credit', 'debit'] as const).map(t => (
                <button key={t} onClick={() => setBalanceType(t)}
                  className="flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-semibold transition-all capitalize"
                  style={balanceType === t
                    ? t === 'credit'
                      ? { background: 'rgba(34,197,94,0.2)', color: '#22c55e', border: '1px solid rgba(34,197,94,0.4)' }
                      : { background: 'rgba(239,68,68,0.2)', color: '#f87171', border: '1px solid rgba(239,68,68,0.4)' }
                    : { color: '#64748b' }}>
                  {t === 'credit' ? <ArrowUpCircle className="w-4 h-4" /> : <ArrowDownCircle className="w-4 h-4" />}
                  {t}
                </button>
              ))}
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium mb-1" style={{ color: '#94a3b8' }}>Amount (USD) *</label>
                <input type="number" value={balanceAmount} onChange={e => setBalanceAmount(e.target.value)} placeholder="0.00" min="0.01" step="0.01"
                  className={inputCls} style={S} />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1" style={{ color: '#94a3b8' }}>Reason *</label>
                <input value={balanceReason} onChange={e => setBalanceReason(e.target.value)} placeholder="e.g. Manual recovery credit, fee deduction..."
                  className={inputCls} style={S} />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1" style={{ color: '#94a3b8' }}>Reference ID (optional)</label>
                <input value={balanceRef} onChange={e => setBalanceRef(e.target.value)} placeholder="e.g. TXN-001234"
                  className={inputCls} style={S} />
              </div>
            </div>

            <div className="flex gap-3 mt-5">
              <button onClick={submitBalance} disabled={!balanceAmount || !balanceReason}
                className="flex-1 h-11 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all"
                style={{ background: balanceType === 'credit' ? '#22c55e' : '#ef4444', color: '#fff', opacity: !balanceAmount || !balanceReason ? 0.5 : 1 }}>
                {balanceType === 'credit' ? <><PlusCircle className="w-4 h-4" /> Credit Balance</> : <><MinusCircle className="w-4 h-4" /> Debit Balance</>}
              </button>
              <button onClick={() => setBalanceModal(null)} className="px-5 h-11 rounded-xl font-medium" style={{ background: '#1a3a5c', color: '#94a3b8' }}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* ── MODAL: Withdrawal Action ──────────────────────────────────────── */}
      {withdrawalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.75)' }}>
          <div className="w-full max-w-md rounded-2xl p-6" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-lg font-bold text-white">Manage Withdrawal</h3>
                <p className="text-xs mt-0.5" style={{ color: '#94a3b8' }}>
                  ${Number(withdrawalModal.amount).toLocaleString()} · {withdrawalModal.profiles?.email}
                </p>
              </div>
              <button onClick={() => setWithdrawalModal(null)} style={{ color: '#94a3b8' }}><X className="w-5 h-5" /></button>
            </div>

            <div className="rounded-xl p-3 mb-5 flex items-center gap-3" style={{ background: '#0a1628', border: '1px solid #1e4976' }}>
              <span className="text-xs" style={{ color: '#94a3b8' }}>Current status:</span>
              <StatusBadge status={withdrawalModal.status} />
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium mb-2" style={{ color: '#94a3b8' }}>Set New Status *</label>
                <div className="grid grid-cols-3 gap-2">
                  {WITHDRAWAL_STATUSES.map(s => {
                    const st = statusStyle[s] || { bg: '', color: '#fff', icon: Clock };
                    const Icon = st.icon;
                    return (
                      <button key={s} onClick={() => setWdAction(s)}
                        className="flex flex-col items-center gap-1 py-2.5 px-2 rounded-xl text-xs font-semibold capitalize transition-all"
                        style={wdAction === s
                          ? { background: st.bg, color: st.color, border: `1px solid ${st.color}` }
                          : { background: '#0a1628', color: '#64748b', border: '1px solid #1e4976' }}>
                        <Icon className="w-4 h-4" />{s}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium mb-1" style={{ color: '#94a3b8' }}>Admin Note (sent to user)</label>
                <textarea value={wdNote} onChange={e => setWdNote(e.target.value)} rows={3} placeholder="Optional note for the user..."
                  className="w-full px-3 py-2 rounded-lg text-white text-sm outline-none resize-none" style={S} />
              </div>
            </div>

            <div className="flex gap-3 mt-5">
              <button onClick={submitWithdrawalAction}
                className="flex-1 h-11 rounded-xl font-semibold flex items-center justify-center gap-2"
                style={{ background: '#d4a853', color: '#0a1628' }}>
                <Check className="w-4 h-4" /> Apply Action
              </button>
              <button onClick={() => setWithdrawalModal(null)} className="px-5 h-11 rounded-xl font-medium" style={{ background: '#1a3a5c', color: '#94a3b8' }}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* ── MODAL: Set Withdrawal Limit ───────────────────────────────────── */}
      {limitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.75)' }}>
          <div className="w-full max-w-md rounded-2xl p-6" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-lg font-bold text-white">Set Daily Withdrawal Limit</h3>
                <p className="text-xs mt-0.5" style={{ color: '#94a3b8' }}>{limitModal.email}</p>
              </div>
              <button onClick={() => setLimitModal(null)} style={{ color: '#94a3b8' }}><X className="w-5 h-5" /></button>
            </div>

            <div className="rounded-xl p-3 mb-5 flex items-center justify-between" style={{ background: '#0a1628' }}>
              <span className="text-xs" style={{ color: '#94a3b8' }}>Current limit</span>
              <span className="font-bold text-white">${Number(limitModal.daily_withdrawal_limit).toLocaleString()}</span>
            </div>

            {/* Quick presets */}
            <div className="grid grid-cols-4 gap-2 mb-4">
              {[1000, 5000, 10000, 50000].map(v => (
                <button key={v} onClick={() => setNewLimit(String(v))}
                  className="py-2 rounded-lg text-xs font-semibold transition-all"
                  style={newLimit === String(v)
                    ? { background: 'rgba(212,168,83,0.2)', color: '#d4a853', border: '1px solid rgba(212,168,83,0.4)' }
                    : { background: '#0a1628', color: '#64748b', border: '1px solid #1e4976' }}>
                  ${v >= 1000 ? `${v / 1000}k` : v}
                </button>
              ))}
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium mb-1" style={{ color: '#94a3b8' }}>Custom Limit (USD) *</label>
                <input type="number" value={newLimit} onChange={e => setNewLimit(e.target.value)} placeholder="Enter amount" min="0" step="1"
                  className={inputCls} style={S} />
              </div>
              <div>
                <label className="block text-xs font-medium mb-1" style={{ color: '#94a3b8' }}>Reason (optional)</label>
                <input value={limitReason} onChange={e => setLimitReason(e.target.value)} placeholder="e.g. Verified high-value client"
                  className={inputCls} style={S} />
              </div>
            </div>

            <div className="flex gap-3 mt-5">
              <button onClick={submitLimit} disabled={!newLimit}
                className="flex-1 h-11 rounded-xl font-semibold flex items-center justify-center gap-2"
                style={{ background: '#3b82f6', color: '#fff', opacity: !newLimit ? 0.5 : 1 }}>
                <Lock className="w-4 h-4" /> Set Limit
              </button>
              <button onClick={() => setLimitModal(null)} className="px-5 h-11 rounded-xl font-medium" style={{ background: '#1a3a5c', color: '#94a3b8' }}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* ── MODAL: Edit User ──────────────────────────────────────────────── */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.75)' }}>
          <div className="w-full max-w-md rounded-2xl p-6" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-bold text-white">Edit User</h3>
              <button onClick={() => setEditingUser(null)} style={{ color: '#94a3b8' }}><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-3">
              <div><label className="block text-xs mb-1" style={{ color: '#94a3b8' }}>First Name</label>
                <input value={editingUser.first_name || ''} onChange={e => setEditingUser({ ...editingUser, first_name: e.target.value })} className={inputCls} style={S} /></div>
              <div><label className="block text-xs mb-1" style={{ color: '#94a3b8' }}>Last Name</label>
                <input value={editingUser.last_name || ''} onChange={e => setEditingUser({ ...editingUser, last_name: e.target.value })} className={inputCls} style={S} /></div>
              <div><label className="block text-xs mb-1" style={{ color: '#94a3b8' }}>Phone</label>
                <input value={editingUser.phone || ''} onChange={e => setEditingUser({ ...editingUser, phone: e.target.value })} className={inputCls} style={S} /></div>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => updateUser(editingUser.user_id, { first_name: editingUser.first_name, last_name: editingUser.last_name, phone: editingUser.phone })}
                className="flex-1 h-11 rounded-xl font-semibold flex items-center justify-center gap-2" style={{ background: '#d4a853', color: '#0a1628' }}>
                <Check className="w-4 h-4" /> Save
              </button>
              <button onClick={() => setEditingUser(null)} className="px-5 h-11 rounded-xl" style={{ background: '#1a3a5c', color: '#94a3b8' }}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* ── MODAL: Edit Case ──────────────────────────────────────────────── */}
      {editingCase && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.75)' }}>
          <div className="w-full max-w-md rounded-2xl p-6" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-lg font-bold text-white">Edit Case</h3>
                <p className="text-xs font-mono mt-0.5" style={{ color: '#d4a853' }}>{editingCase.case_id}</p>
              </div>
              <button onClick={() => setEditingCase(null)} style={{ color: '#94a3b8' }}><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-3">
              <div><label className="block text-xs mb-1" style={{ color: '#94a3b8' }}>Status</label>
                <select value={editingCase.status} onChange={e => setEditingCase({ ...editingCase, status: e.target.value })}
                  className="w-full h-10 px-3 rounded-lg text-white text-sm outline-none" style={S}>
                  {['under_review', 'in_progress', 'recovered', 'closed'].map(s => <option key={s} value={s}>{s.replace('_', ' ')}</option>)}
                </select>
              </div>
              <div><label className="block text-xs mb-1" style={{ color: '#94a3b8' }}>Amount Recovered ($)</label>
                <input type="number" value={editingCase.amount_recovered} onChange={e => setEditingCase({ ...editingCase, amount_recovered: parseFloat(e.target.value) })} className={inputCls} style={S} /></div>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => updateCase(editingCase.id, { status: editingCase.status, amount_recovered: editingCase.amount_recovered })}
                className="flex-1 h-11 rounded-xl font-semibold flex items-center justify-center gap-2" style={{ background: '#d4a853', color: '#0a1628' }}>
                <Check className="w-4 h-4" /> Save
              </button>
              <button onClick={() => setEditingCase(null)} className="px-5 h-11 rounded-xl" style={{ background: '#1a3a5c', color: '#94a3b8' }}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* ── MODAL: Send Message ───────────────────────────────────────────── */}
      {messageModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.75)' }}>
          <div className="w-full max-w-md rounded-2xl p-6" style={{ background: '#0f2140', border: '1px solid #1e4976' }}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-bold text-white">Send Message to User</h3>
              <button onClick={() => setMessageModal(null)} style={{ color: '#94a3b8' }}><X className="w-5 h-5" /></button>
            </div>
            <textarea value={messageText} onChange={e => setMessageText(e.target.value)} placeholder="Type your message..." rows={5}
              className="w-full px-3 py-2 rounded-xl text-white text-sm outline-none resize-none mb-4" style={S} />
            <div className="flex gap-3">
              <button onClick={sendMessage} disabled={!messageText.trim()}
                className="flex-1 h-11 rounded-xl font-semibold flex items-center justify-center gap-2"
                style={{ background: '#d4a853', color: '#0a1628', opacity: !messageText.trim() ? 0.5 : 1 }}>
                <Send className="w-4 h-4" /> Send Message
              </button>
              <button onClick={() => setMessageModal(null)} className="px-5 h-11 rounded-xl" style={{ background: '#1a3a5c', color: '#94a3b8' }}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
