import { Quote } from 'lucide-react';

const stats = [
  { value: '15+', label: 'Years of Experience' },
  { value: '350,000+', label: 'Cases Handled' },
  { value: '99.8%', label: 'Recovery Rate' },
  { value: '100+', label: 'Licensed Professionals' },
];

export default function About() {
  return (
    <section id="about" className="py-16 md:py-24" style={{ background: '#0f2140' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">About Consumer Recovery Agency</h2>
        </div>
        <div className="max-w-4xl mx-auto">
          <p className="text-lg mb-6 text-center" style={{ color: '#94a3b8' }}>
            Consumer Recovery Agency is a leading financial recovery firm dedicated to helping individuals and families reclaim funds lost to fraud, scams, unauthorized charges, and financial disputes.
          </p>
          <p className="text-lg mb-6 text-center" style={{ color: '#94a3b8' }}>
            Founded by financial industry veterans and consumer protection advocates, our mission is simple: to recover what's rightfully yours. We understand the emotional and financial toll that losing money can take, which is why we approach every case with empathy, expertise, and determination.
          </p>
          <p className="text-lg mb-10 text-center" style={{ color: '#94a3b8' }}>
            Our team of licensed professionals includes former banking executives, fraud investigators, and legal experts who know how to navigate complex financial systems and fight for our clients' rights.
          </p>
          <div className="rounded-xl p-8 mb-12 text-center" style={{ background: 'rgba(26,58,92,0.5)', border: '1px solid #1e4976' }}>
            <Quote className="h-8 w-8 mx-auto mb-4" style={{ color: '#d4a853' }} />
            <blockquote className="text-white text-lg italic mb-4">
              "We believe every consumer deserves a fair chance at recovering their hard-earned money. Our success is measured not just in dollars recovered, but in the peace of mind we restore."
            </blockquote>
            <cite className="text-sm not-italic" style={{ color: '#d4a853' }}>— Consumer Recovery Agency Leadership Team</cite>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
          {stats.map(stat => (
            <div key={stat.label} className="text-center p-6 rounded-xl" style={{ background: 'rgba(26,58,92,0.3)', border: '1px solid #1e4976' }}>
              <div className="text-3xl md:text-4xl font-bold mb-2" style={{ color: '#d4a853' }}>{stat.value}</div>
              <div className="text-sm" style={{ color: '#94a3b8' }}>{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
