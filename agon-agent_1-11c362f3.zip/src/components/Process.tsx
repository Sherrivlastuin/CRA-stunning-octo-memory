import { MessageSquare, Search, Scale, Banknote, Award, Lock, ShieldCheck, Trophy } from 'lucide-react';

const steps = [
  { icon: MessageSquare, title: 'Free Consultation', description: 'Share your case details with our specialists. We\'ll evaluate your situation and determine the best recovery strategy.' },
  { icon: Search, title: 'Case Investigation', description: 'Our team conducts a thorough investigation, gathering evidence and identifying all responsible parties.' },
  { icon: Scale, title: 'Recovery Action', description: 'We pursue your claim through proper channels, negotiating with institutions and leveraging consumer protection laws.' },
  { icon: Banknote, title: 'Fund Recovery', description: 'Upon successful resolution, your recovered funds are returned to you directly. You only pay if we succeed.' },
];

const badges = [
  { icon: Award, title: 'BBB Accredited', description: 'A+ Rating with the Better Business Bureau' },
  { icon: Lock, title: 'Secure & Confidential', description: 'Bank-level encryption protects your data' },
  { icon: ShieldCheck, title: 'Legal Compliance', description: 'Fully compliant with all consumer protection laws' },
  { icon: Trophy, title: 'Industry Recognized', description: 'Award-winning recovery specialists' },
];

export default function Process() {
  return (
    <section id="process" className="py-16 md:py-24" style={{ background: '#0f2140' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">How It Works</h2>
          <p className="text-lg max-w-2xl mx-auto" style={{ color: '#94a3b8' }}>Our streamlined process makes fund recovery straightforward and stress-free.</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {steps.map((step, index) => (
            <div key={step.title} className="relative">
              <div className="rounded-xl p-6 h-full" style={{ background: 'rgba(26,58,92,0.3)', border: '1px solid #1e4976' }}>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm" style={{ background: '#d4a853', color: '#0a1628' }}>{index + 1}</div>
                  <step.icon className="h-6 w-6" style={{ color: '#d4a853' }} />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{step.title}</h3>
                <p className="text-sm" style={{ color: '#94a3b8' }}>{step.description}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {badges.map(({ icon: Icon, title, description }) => (
            <div key={title} className="rounded-lg p-4 text-center" style={{ background: 'rgba(26,58,92,0.2)', border: '1px solid #1e4976' }}>
              <Icon className="h-8 w-8 mx-auto mb-2" style={{ color: '#d4a853' }} />
              <h4 className="font-semibold text-white text-sm mb-1">{title}</h4>
              <p className="text-xs" style={{ color: '#94a3b8' }}>{description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
