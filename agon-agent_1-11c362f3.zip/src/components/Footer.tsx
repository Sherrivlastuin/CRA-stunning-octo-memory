import { Shield, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Footer() {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="py-12" style={{ background: '#0a1628', borderTop: '1px solid #1e4976' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <Link to="/" className="flex items-center gap-2">
              <Shield className="h-6 w-6" style={{ color: '#d4a853' }} />
              <div className="flex flex-col">
                <span className="text-sm font-bold text-white leading-tight">Consumer Recovery</span>
                <span className="text-xs font-medium leading-tight" style={{ color: '#d4a853' }}>AGENCY</span>
              </div>
            </Link>
            <nav className="flex flex-wrap items-center justify-center gap-6">
              {['about', 'services', 'process', 'faq', 'contact'].map(s => (
                <button key={s} onClick={() => scrollTo(s)} className="text-sm capitalize transition-colors" style={{ color: '#94a3b8' }}
                  onMouseEnter={e => (e.currentTarget.style.color = '#fff')}
                  onMouseLeave={e => (e.currentTarget.style.color = '#94a3b8')}>{s}</button>
              ))}
            </nav>
          </div>
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 pt-6" style={{ borderTop: '1px solid #1e4976' }}>
            <p className="text-sm text-center md:text-left" style={{ color: '#94a3b8' }}>© {new Date().getFullYear()} Consumer Recovery Agency. All rights reserved.</p>
            <Link to="/auth/admin-login" className="flex items-center gap-2 text-sm transition-colors" style={{ color: '#94a3b8' }}
              onMouseEnter={e => (e.currentTarget.style.color = '#fff')}
              onMouseLeave={e => (e.currentTarget.style.color = '#94a3b8')}>
              <Lock className="h-4 w-4" /> Admin Login
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
