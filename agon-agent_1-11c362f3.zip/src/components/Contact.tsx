import { useState } from 'react';
import { Mail, Clock, MapPin, Shield, Send } from 'lucide-react';

const caseTypes = ['Fraud Recovery', 'Unauthorized Charges', 'Bank Disputes', 'Investment Recovery', 'Identity Theft', 'Consumer Refunds', 'Other'];

export default function Contact() {
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', phone: '', caseType: '', estimatedLoss: '', description: '' });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    await new Promise(r => setTimeout(r, 1500));
    setSubmitting(false);
    setSubmitted(true);
  };

  return (
    <section id="contact" className="py-16 md:py-24" style={{ background: '#0f2140' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Start Your Free Case Review</h2>
          <p className="text-lg max-w-2xl mx-auto" style={{ color: '#94a3b8' }}>Tell us about your situation. A recovery specialist will contact you within 24 hours.</p>
        </div>
        <div className="grid lg:grid-cols-2 gap-12">
          <div className="rounded-xl p-6 md:p-8" style={{ background: 'rgba(26,58,92,0.3)', border: '1px solid #1e4976' }}>
            <h3 className="text-xl font-semibold text-white mb-2">Request a Free Consultation</h3>
            <p className="text-sm mb-6" style={{ color: '#94a3b8' }}>Fill out the form below and we'll get back to you promptly. All information is kept strictly confidential.</p>
            {submitted ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: 'rgba(34,197,94,0.2)' }}>
                  <Shield className="h-8 w-8" style={{ color: '#22c55e' }} />
                </div>
                <h4 className="text-xl font-semibold text-white mb-2">Thank You!</h4>
                <p style={{ color: '#94a3b8' }}>Your case has been submitted. A recovery specialist will contact you within 24 hours.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1" style={{ color: '#94a3b8' }}>First Name *</label>
                    <input required value={form.firstName} onChange={e => setForm({ ...form, firstName: e.target.value })} className="w-full h-11 px-3 rounded-lg text-white text-sm outline-none" style={{ background: '#0a1628', border: '1px solid #1e4976' }} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1" style={{ color: '#94a3b8' }}>Last Name *</label>
                    <input required value={form.lastName} onChange={e => setForm({ ...form, lastName: e.target.value })} className="w-full h-11 px-3 rounded-lg text-white text-sm outline-none" style={{ background: '#0a1628', border: '1px solid #1e4976' }} />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1" style={{ color: '#94a3b8' }}>Email *</label>
                    <input type="email" required value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} className="w-full h-11 px-3 rounded-lg text-white text-sm outline-none" style={{ background: '#0a1628', border: '1px solid #1e4976' }} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1" style={{ color: '#94a3b8' }}>Phone *</label>
                    <input type="tel" required value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} className="w-full h-11 px-3 rounded-lg text-white text-sm outline-none" style={{ background: '#0a1628', border: '1px solid #1e4976' }} />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1" style={{ color: '#94a3b8' }}>Type of Case *</label>
                    <select required value={form.caseType} onChange={e => setForm({ ...form, caseType: e.target.value })} className="w-full h-11 px-3 rounded-lg text-white text-sm outline-none" style={{ background: '#0a1628', border: '1px solid #1e4976' }}>
                      <option value="">Select case type</option>
                      {caseTypes.map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1" style={{ color: '#94a3b8' }}>Estimated Loss</label>
                    <input placeholder="$" value={form.estimatedLoss} onChange={e => setForm({ ...form, estimatedLoss: e.target.value })} className="w-full h-11 px-3 rounded-lg text-white text-sm outline-none" style={{ background: '#0a1628', border: '1px solid #1e4976' }} />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1" style={{ color: '#94a3b8' }}>Describe Your Situation *</label>
                  <textarea required rows={4} value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} className="w-full px-3 py-2 rounded-lg text-white text-sm outline-none resize-none" style={{ background: '#0a1628', border: '1px solid #1e4976' }} />
                </div>
                <button type="submit" disabled={submitting} className="w-full h-12 rounded-lg font-semibold text-base flex items-center justify-center gap-2 transition-colors" style={{ background: '#d4a853', color: '#0a1628' }}>
                  {submitting ? 'Submitting...' : <><Send className="h-4 w-4" /> Submit for Free Review</>}
                </button>
                <p className="text-xs text-center flex items-center justify-center gap-1" style={{ color: '#94a3b8' }}>
                  <Shield className="h-3 w-3" /> Your information is protected with bank-level encryption.
                </p>
              </form>
            )}
          </div>
          <div className="space-y-8">
            <div>
              <h3 className="text-xl font-semibold text-white mb-4">Get in Touch</h3>
              <p style={{ color: '#94a3b8' }} className="mb-6">Prefer to speak with someone directly? Our team is available to answer your questions and provide immediate assistance with your case.</p>
            </div>
            <div className="space-y-4">
              {[
                { icon: Mail, title: 'Email', content: <a href="mailto:consumer.recovery@outlook.com" style={{ color: '#d4a853' }}>consumer.recovery@outlook.com</a>, sub: 'We respond within 24 hours' },
                { icon: Clock, title: 'Hours', content: <span style={{ color: '#94a3b8' }}>Mon-Fri: 8AM-8PM EST</span>, sub: 'Sat: 9AM-5PM EST' },
                { icon: MapPin, title: 'Service Area', content: <span style={{ color: '#d4a853' }}>Nationwide Coverage</span>, sub: 'Serving all 50 states' },
              ].map(({ icon: Icon, title, content, sub }) => (
                <div key={title} className="flex items-start gap-4 p-4 rounded-lg" style={{ background: 'rgba(26,58,92,0.3)', border: '1px solid #1e4976' }}>
                  <Icon className="h-6 w-6 mt-0.5" style={{ color: '#d4a853' }} />
                  <div>
                    <h4 className="font-semibold text-white">{title}</h4>
                    {content}
                    <p className="text-sm mt-1" style={{ color: '#94a3b8' }}>{sub}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="rounded-xl p-6" style={{ background: 'rgba(212,168,83,0.1)', border: '1px solid rgba(212,168,83,0.3)' }}>
              <h4 className="font-semibold text-white mb-2">Need Immediate Help?</h4>
              <p className="text-sm mb-4" style={{ color: '#94a3b8' }}>Our specialists are standing by to assist you. Contact us now for a free, confidential consultation.</p>
              <a href="mailto:consumer.recovery@outlook.com" className="inline-flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-colors" style={{ background: '#d4a853', color: '#0a1628' }}>
                <Mail className="h-4 w-4" /> Email Us Now
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
