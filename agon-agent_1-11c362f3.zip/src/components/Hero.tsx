import { Shield, Lock, Users, CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Hero() {
  return (
    <section className="relative pt-24 pb-16 md:pt-32 md:pb-24 overflow-hidden">
      <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, #0a1628, #0a1628, #0f2140)' }} />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 rounded-full px-4 py-2 mb-6" style={{ background: 'rgba(212,168,83,0.1)', border: '1px solid rgba(212,168,83,0.2)' }}>
            <Shield className="h-4 w-4" style={{ color: '#d4a853' }} />
            <span className="text-sm font-medium" style={{ color: '#d4a853' }}>Trusted by 2,800,000+ Consumers Nationwide</span>
          </div>

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
            Recover What&apos;s Rightfully Yours
          </h1>

          <p className="text-lg md:text-xl max-w-3xl mx-auto mb-8" style={{ color: '#94a3b8' }}>
            Lost funds to fraud, scams, or unauthorized charges? Our expert team has helped consumers recover over $30 billion. Let us fight for your money.
          </p>

          <Link to="/auth/sign-up"
            className="inline-flex items-center gap-2 px-8 py-4 rounded-lg font-semibold text-lg transition-colors"
            style={{ background: '#d4a853', color: '#0a1628' }}>
            Start Your Free Case Review
          </Link>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12 max-w-3xl mx-auto">
            {[
              { icon: Lock, text: 'Confidential & secure' },
              { icon: Users, text: 'Experienced recovery specialists' },
              { icon: CheckCircle, text: 'Free case evaluation' },
              { icon: Shield, text: 'No upfront fees' },
            ].map(({ icon: Icon, text }) => (
              <div key={text} className="flex items-center gap-2 justify-center">
                <Icon className="h-5 w-5" style={{ color: '#d4a853' }} />
                <span className="text-sm" style={{ color: '#94a3b8' }}>{text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
