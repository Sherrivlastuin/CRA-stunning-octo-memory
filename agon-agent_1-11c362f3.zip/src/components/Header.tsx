import { Shield, User, LogIn, Menu, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { getCurrentUser } from '../lib/auth';

export default function Header() {
  const [user, setUser] = useState<any>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  useEffect(() => {
    getCurrentUser().then(setUser);
  }, []);

  const scrollTo = (id: string) => {
    setMenuOpen(false);
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50" style={{ background: 'rgba(10,22,40,0.97)', borderBottom: '1px solid #1e4976', backdropFilter: 'blur(8px)' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2">
            <Shield className="h-8 w-8" style={{ color: '#d4a853' }} />
            <div className="flex flex-col">
              <span className="text-lg font-bold text-white leading-tight">Consumer Recovery</span>
              <span className="text-xs font-medium leading-tight" style={{ color: '#d4a853' }}>AGENCY</span>
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-8">
            {['about', 'services', 'process', 'faq', 'contact'].map(s => (
              <button key={s} onClick={() => scrollTo(s)} className="text-sm capitalize transition-colors" style={{ color: '#94a3b8' }}
                onMouseEnter={e => (e.currentTarget.style.color = '#fff')}
                onMouseLeave={e => (e.currentTarget.style.color = '#94a3b8')}>
                {s}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            {user ? (
              <Link to={user.isAdmin ? '/admin' : '/dashboard'}
                className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm transition-colors"
                style={{ background: '#d4a853', color: '#0a1628' }}>
                <User className="h-4 w-4" />
                {user.isAdmin ? 'Admin Panel' : 'Dashboard'}
              </Link>
            ) : (
              <>
                <Link to="/auth/login" className="hidden sm:flex items-center gap-2 text-sm transition-colors" style={{ color: '#94a3b8' }}
                  onMouseEnter={e => (e.currentTarget.style.color = '#fff')}
                  onMouseLeave={e => (e.currentTarget.style.color = '#94a3b8')}>
                  <LogIn className="h-4 w-4" /> Sign In
                </Link>
                <Link to="/auth/sign-up"
                  className="px-4 py-2 rounded-lg font-medium text-sm transition-colors"
                  style={{ background: '#d4a853', color: '#0a1628' }}>
                  Free Consultation
                </Link>
              </>
            )}
            <button className="md:hidden" onClick={() => setMenuOpen(!menuOpen)} style={{ color: '#94a3b8' }}>
              {menuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {menuOpen && (
          <div className="md:hidden pb-4" style={{ borderTop: '1px solid #1e4976' }}>
            <div className="flex flex-col gap-2 pt-4">
              {['about', 'services', 'process', 'faq', 'contact'].map(s => (
                <button key={s} onClick={() => scrollTo(s)} className="text-left px-2 py-2 text-sm capitalize" style={{ color: '#94a3b8' }}>
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
