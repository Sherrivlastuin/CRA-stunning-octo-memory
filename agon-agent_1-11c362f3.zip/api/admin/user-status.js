import supabase from '../_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  const { data: session } = await supabase
    .from('auth_sessions').select('user_id')
    .eq('id', token).gt('expires_at', new Date().toISOString()).single();
  if (!session) return res.status(401).json({ error: 'Invalid session' });

  const { data: adminProfile } = await supabase.from('profiles').select('is_admin').eq('user_id', session.user_id).single();
  if (!adminProfile?.is_admin) return res.status(403).json({ error: 'Admin access required' });

  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { user_id, is_active, reason } = req.body;
    if (user_id === undefined || is_active === undefined) return res.status(400).json({ error: 'user_id and is_active are required' });

    const { data, error } = await supabase
      .from('profiles')
      .update({ is_active })
      .eq('user_id', user_id)
      .select().single();
    if (error) throw error;

    // If deactivating, kill all sessions
    if (!is_active) {
      await supabase.from('auth_sessions').delete().eq('user_id', user_id);
    }

    await supabase.from('audit_logs').insert({
      admin_user_id: session.user_id,
      action: is_active ? 'account_activated' : 'account_deactivated',
      target_user_id: user_id,
      details: { reason: reason || null, is_active }
    });

    return res.status(200).json({ ok: true, user: data, message: `Account ${is_active ? 'activated' : 'deactivated'} successfully` });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
