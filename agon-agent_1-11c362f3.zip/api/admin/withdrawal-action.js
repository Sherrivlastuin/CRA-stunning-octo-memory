import supabase from '../_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  const { data: session } = await supabase
    .from('auth_sessions').select('user_id')
    .eq('id', token).gt('expires_at', new Date().toISOString()).single();
  if (!session) return res.status(401).json({ error: 'Invalid session' });

  const { data: adminProfile } = await supabase.from('profiles').select('is_admin').eq('user_id', session.user_id).single();
  if (!adminProfile?.is_admin) return res.status(403).json({ error: 'Admin access required' });

  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const VALID_STATUSES = ['pending', 'processing', 'successful', 'failed', 'retry'];

  try {
    const { withdrawal_id, action, admin_note } = req.body;
    if (!withdrawal_id || !action) return res.status(400).json({ error: 'withdrawal_id and action are required' });
    if (!VALID_STATUSES.includes(action)) return res.status(400).json({ error: `action must be one of: ${VALID_STATUSES.join(', ')}` });

    const { data: existing } = await supabase.from('withdrawals').select('*').eq('id', withdrawal_id).single();
    if (!existing) return res.status(404).json({ error: 'Withdrawal not found' });

    const newStatus = action === 'retry' ? 'pending' : action;

    const { data, error } = await supabase
      .from('withdrawals')
      .update({ status: newStatus, admin_note: admin_note || existing.admin_note })
      .eq('id', withdrawal_id)
      .select().single();
    if (error) throw error;

    await supabase.from('audit_logs').insert({
      admin_user_id: session.user_id,
      action: `withdrawal_${action}`,
      target_user_id: existing.user_id,
      details: { withdrawal_id, previous_status: existing.status, new_status: newStatus, amount: existing.amount, admin_note }
    });

    // Notify user via message
    const statusMessages: Record<string, string> = {
      processing: `Your withdrawal of $${parseFloat(existing.amount).toLocaleString()} is now being processed. Expected completion within 1-3 business days.`,
      successful: `Great news! Your withdrawal of $${parseFloat(existing.amount).toLocaleString()} has been successfully processed and sent to your account.`,
      failed: `Your withdrawal of $${parseFloat(existing.amount).toLocaleString()} could not be completed. ${admin_note ? 'Reason: ' + admin_note : 'Please contact support for assistance.'}`,
      retry: `Your withdrawal of $${parseFloat(existing.amount).toLocaleString()} has been reset to pending and will be retried shortly.`,
      pending: `Your withdrawal of $${parseFloat(existing.amount).toLocaleString()} is queued and pending review.`,
    };

    await supabase.from('messages').insert({
      user_id: existing.user_id,
      case_id: existing.case_id || null,
      sender_type: 'admin',
      message: statusMessages[action] || `Your withdrawal status has been updated to: ${newStatus}.`,
    });

    return res.status(200).json({ ok: true, withdrawal: data });
  } catch (err) {
    console.error('Withdrawal action error:', err);
    return res.status(500).json({ error: err.message });
  }
}
