import supabase from '../_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  const { data: session } = await supabase
    .from('auth_sessions').select('user_id')
    .eq('id', token).gt('expires_at', new Date().toISOString()).single();
  if (!session) return res.status(401).json({ error: 'Invalid session' });

  const { data: adminProfile } = await supabase.from('profiles').select('is_admin').eq('user_id', session.user_id).single();
  if (!adminProfile?.is_admin) return res.status(403).json({ error: 'Admin access required' });

  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { user_id, daily_withdrawal_limit, reason } = req.body;
    if (!user_id || daily_withdrawal_limit === undefined) return res.status(400).json({ error: 'user_id and daily_withdrawal_limit are required' });
    if (parseFloat(daily_withdrawal_limit) < 0) return res.status(400).json({ error: 'Limit cannot be negative' });

    const { data: existing } = await supabase.from('profiles').select('daily_withdrawal_limit').eq('user_id', user_id).single();

    const { data, error } = await supabase
      .from('profiles')
      .update({ daily_withdrawal_limit: parseFloat(daily_withdrawal_limit) })
      .eq('user_id', user_id)
      .select().single();
    if (error) throw error;

    await supabase.from('audit_logs').insert({
      admin_user_id: session.user_id,
      action: 'withdrawal_limit_updated',
      target_user_id: user_id,
      details: { previous_limit: existing?.daily_withdrawal_limit, new_limit: parseFloat(daily_withdrawal_limit), reason: reason || null }
    });

    await supabase.from('messages').insert({
      user_id,
      sender_type: 'admin',
      message: `Your daily withdrawal limit has been updated to $${parseFloat(daily_withdrawal_limit).toLocaleString()}. ${reason ? 'Note: ' + reason : ''}`,
    });

    return res.status(200).json({ ok: true, profile: data });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
