import supabase from '../_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  const { data: session } = await supabase
    .from('auth_sessions').select('user_id')
    .eq('id', token).gt('expires_at', new Date().toISOString()).single();
  if (!session) return res.status(401).json({ error: 'Invalid session' });

  const { data: adminProfile } = await supabase.from('profiles').select('is_admin').eq('user_id', session.user_id).single();
  if (!adminProfile?.is_admin) return res.status(403).json({ error: 'Admin access required' });

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('balance_adjustments')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(200);
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { user_id, type, amount, reason, reference_id } = req.body;
      if (!user_id || !type || !amount) return res.status(400).json({ error: 'user_id, type, and amount are required' });
      if (!['credit', 'debit'].includes(type)) return res.status(400).json({ error: 'type must be credit or debit' });
      if (parseFloat(amount) <= 0) return res.status(400).json({ error: 'Amount must be positive' });

      // Calculate current balance from cases (recovered amounts)
      const { data: userCases } = await supabase.from('cases').select('amount_recovered').eq('user_id', user_id);
      const { data: adjustments } = await supabase.from('balance_adjustments').select('type, amount').eq('user_id', user_id);
      
      const caseBalance = (userCases || []).reduce((s, c) => s + parseFloat(c.amount_recovered || 0), 0);
      const adjustmentBalance = (adjustments || []).reduce((s, a) => {
        return a.type === 'credit' ? s + parseFloat(a.amount) : s - parseFloat(a.amount);
      }, 0);
      const currentBalance = caseBalance + adjustmentBalance;

      if (type === 'debit' && parseFloat(amount) > currentBalance) {
        return res.status(400).json({ error: `Insufficient balance. Current: $${currentBalance.toFixed(2)}` });
      }

      const balanceBefore = currentBalance;
      const balanceAfter = type === 'credit' ? currentBalance + parseFloat(amount) : currentBalance - parseFloat(amount);

      const { data: adjustment, error: adjError } = await supabase
        .from('balance_adjustments')
        .insert({ user_id, admin_user_id: session.user_id, type, amount: parseFloat(amount), balance_before: balanceBefore, balance_after: balanceAfter, reason: reason || null, reference_id: reference_id || null })
        .select().single();
      if (adjError) throw adjError;

      // Audit log
      await supabase.from('audit_logs').insert({
        admin_user_id: session.user_id, action: `balance_${type}`,
        target_user_id: user_id,
        details: { amount: parseFloat(amount), balance_before: balanceBefore, balance_after: balanceAfter, reason, reference_id }
      });

      return res.status(201).json({ adjustment, balance_before: balanceBefore, balance_after: balanceAfter });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Balance error:', err);
    return res.status(500).json({ error: err.message });
  }
}
