import supabase from '../_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  const { data: session } = await supabase
    .from('auth_sessions').select('user_id')
    .eq('id', token).gt('expires_at', new Date().toISOString()).single();
  if (!session) return res.status(401).json({ error: 'Invalid session' });

  const { data: adminProfile } = await supabase.from('profiles').select('is_admin').eq('user_id', session.user_id).single();
  if (!adminProfile?.is_admin) return res.status(403).json({ error: 'Admin access required' });

  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { target_user_id, action, limit = 100 } = req.query;
    let query = supabase.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(parseInt(limit));
    if (target_user_id) query = query.eq('target_user_id', target_user_id);
    if (action) query = query.eq('action', action);
    const { data, error } = await query;
    if (error) throw error;
    return res.status(200).json(data);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
