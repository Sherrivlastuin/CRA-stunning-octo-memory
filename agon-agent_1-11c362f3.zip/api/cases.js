import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  // Auth check
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  const { data: session } = await supabase
    .from('auth_sessions')
    .select('user_id')
    .eq('id', token)
    .gt('expires_at', new Date().toISOString())
    .single();
  if (!session) return res.status(401).json({ error: 'Invalid session' });

  const { data: profile } = await supabase.from('profiles').select('is_admin').eq('user_id', session.user_id).single();
  const isAdmin = profile?.is_admin || false;

  try {
    if (req.method === 'GET') {
      let query = supabase.from('cases').select('*, profiles(email, first_name, last_name)').order('created_at', { ascending: false });
      if (!isAdmin) query = query.eq('user_id', session.user_id);
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { title, scam_type, amount_lost, description } = req.body;
      const caseId = 'CRA-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).substring(2, 6).toUpperCase();
      const { data, error } = await supabase
        .from('cases')
        .insert({ user_id: session.user_id, case_id: caseId, title, scam_type, amount_lost, description, status: 'under_review' })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      if (!isAdmin) return res.status(403).json({ error: 'Forbidden' });
      const { id, ...updates } = req.body;
      const { data, error } = await supabase.from('cases').update(updates).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Cases error:', err);
    return res.status(500).json({ error: err.message });
  }
}
