import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  const { data: session } = await supabase
    .from('auth_sessions')
    .select('user_id')
    .eq('id', token)
    .gt('expires_at', new Date().toISOString())
    .single();
  if (!session) return res.status(401).json({ error: 'Invalid session' });

  const { data: profile } = await supabase.from('profiles').select('is_admin').eq('user_id', session.user_id).single();
  const isAdmin = profile?.is_admin || false;

  try {
    if (req.method === 'GET') {
      const { user_id, case_id } = req.query;
      let query = supabase.from('messages').select('*').order('created_at', { ascending: true });
      if (isAdmin && user_id) {
        query = query.eq('user_id', user_id);
      } else if (!isAdmin) {
        query = query.eq('user_id', session.user_id);
      }
      if (case_id) query = query.eq('case_id', case_id);
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const { user_id, case_id, message } = req.body;
      const targetUserId = isAdmin ? user_id : session.user_id;
      const senderType = isAdmin ? 'admin' : 'user';
      const { data, error } = await supabase
        .from('messages')
        .insert({ user_id: targetUserId, case_id: case_id || null, sender_type: senderType, message })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const { id } = req.body;
      const { data, error } = await supabase.from('messages').update({ is_read: true }).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
