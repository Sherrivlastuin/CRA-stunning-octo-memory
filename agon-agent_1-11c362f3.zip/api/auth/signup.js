import crypto from 'crypto';
import supabase from '../_supabase.js';

function hashPassword(password) {
  const salt = crypto.randomBytes(32);
  const key = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha256');
  return salt.toString('hex') + ':' + key.toString('hex');
}

function generateToken() {
  return crypto.randomBytes(32).toString('hex');
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { email, password, firstName, lastName, phone } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    // Check if user exists
    const { data: existing } = await supabase.from('auth_users').select('id').eq('email', email).single();
    if (existing) return res.status(400).json({ error: 'Email already in use' });

    const hashed = hashPassword(password);
    const { data: user, error } = await supabase
      .from('auth_users')
      .insert({ email, password_hash: hashed })
      .select()
      .single();
    if (error) throw error;

    // Create profile
    await supabase.from('profiles').insert({
      user_id: user.id,
      email,
      first_name: firstName || '',
      last_name: lastName || '',
      phone: phone || '',
      is_admin: false,
      daily_withdrawal_limit: 10000,
    });

    const token = generateToken();
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
    await supabase.from('auth_sessions').insert({ id: token, user_id: user.id, expires_at: expiresAt });

    return res.status(201).json({ user: { id: user.id, email: user.email }, token });
  } catch (err) {
    console.error('Signup error:', err);
    return res.status(500).json({ error: err.message });
  }
}
