import crypto from 'crypto';
import supabase from '../_supabase.js';

function verifyPassword(password, storedHash) {
  const [saltHex, keyHex] = storedHash.split(':');
  const salt = Buffer.from(saltHex, 'hex');
  const key = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha256');
  return key.toString('hex') === keyHex;
}

function generateToken() {
  return crypto.randomBytes(32).toString('hex');
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    const { data: user, error } = await supabase
      .from('auth_users')
      .select('id, email, password_hash')
      .eq('email', email)
      .single();

    if (error || !user) return res.status(401).json({ error: 'Invalid credentials' });
    if (!verifyPassword(password, user.password_hash)) return res.status(401).json({ error: 'Invalid credentials' });

    const token = generateToken();
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
    await supabase.from('auth_sessions').insert({ id: token, user_id: user.id, expires_at: expiresAt });

    // Fetch profile for admin check
    const { data: profile } = await supabase
      .from('profiles')
      .select('is_admin, first_name, last_name, is_active')
      .eq('user_id', user.id)
      .single();

    // Block deactivated accounts
    if (profile && profile.is_active === false) {
      return res.status(403).json({ error: 'Your account has been deactivated. Please contact support.' });
    }

    return res.status(200).json({
      user: { id: user.id, email: user.email, isAdmin: profile?.is_admin || false, firstName: profile?.first_name, lastName: profile?.last_name },
      token,
    });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ error: err.message });
  }
}
