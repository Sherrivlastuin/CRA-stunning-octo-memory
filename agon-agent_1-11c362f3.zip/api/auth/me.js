import supabase from '../_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) return res.status(401).json({ error: 'Unauthorized' });

    const { data: session, error } = await supabase
      .from('auth_sessions')
      .select('user_id, auth_users(id, email)')
      .eq('id', token)
      .gt('expires_at', new Date().toISOString())
      .single();

    if (error || !session) return res.status(401).json({ error: 'Invalid or expired session' });

    const { data: profile } = await supabase
      .from('profiles')
      .select('*')
      .eq('user_id', session.user_id)
      .single();

    return res.status(200).json({
      user: {
        id: session.auth_users.id,
        email: session.auth_users.email,
        isAdmin: profile?.is_admin || false,
        firstName: profile?.first_name,
        lastName: profile?.last_name,
        dailyWithdrawalLimit: profile?.daily_withdrawal_limit || 10000,
      },
    });
  } catch (err) {
    console.error('Me error:', err);
    return res.status(500).json({ error: err.message });
  }
}
