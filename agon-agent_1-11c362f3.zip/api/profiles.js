import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  const { data: session } = await supabase
    .from('auth_sessions')
    .select('user_id')
    .eq('id', token)
    .gt('expires_at', new Date().toISOString())
    .single();
  if (!session) return res.status(401).json({ error: 'Invalid session' });

  const { data: myProfile } = await supabase.from('profiles').select('is_admin').eq('user_id', session.user_id).single();
  const isAdmin = myProfile?.is_admin || false;

  try {
    if (req.method === 'GET') {
      if (isAdmin) {
        const { data, error } = await supabase.from('profiles').select('*, auth_users(email)').order('created_at', { ascending: false });
        if (error) throw error;
        return res.status(200).json(data);
      } else {
        const { data, error } = await supabase.from('profiles').select('*').eq('user_id', session.user_id).single();
        if (error) throw error;
        return res.status(200).json(data);
      }
    }

    if (req.method === 'PUT') {
      if (!isAdmin) return res.status(403).json({ error: 'Forbidden' });
      const { user_id, ...updates } = req.body;
      const { data, error } = await supabase.from('profiles').update(updates).eq('user_id', user_id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      if (!isAdmin) return res.status(403).json({ error: 'Forbidden' });
      const { user_id } = req.body;
      await supabase.from('profiles').delete().eq('user_id', user_id);
      await supabase.from('auth_sessions').delete().eq('user_id', user_id);
      await supabase.from('auth_users').delete().eq('id', user_id);
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
